<?php
/**
 * Front page.
 *
 * @package GridlineClub
 */
get_header();
$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
$theme    = get_template_directory_uri();
?>
<main id="main" class="site-main">
	<section class="gl-hero">
		<div class="gl-hero-grid" aria-hidden="true"></div>
		<div class="gl-container gl-hero-inner">
			<div class="gl-hero-copy">
				<p class="gl-kicker"><span></span><?php esc_html_e( 'Authorized racing-radio culture', 'gridline-club' ); ?></p>
				<h1><?php esc_html_e( 'Heard it.', 'gridline-club' ); ?><br><em><?php esc_html_e( 'Wear it.', 'gridline-club' ); ?></em></h1>
				<p><?php esc_html_e( 'The sharpest, funniest radio moments turned into apparel, drinkware, desk gear, and trackside essentials—all under $50.', 'gridline-club' ); ?></p>
				<div class="gl-button-row"><a class="gl-button gl-button--primary" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Shop radio drop 01', 'gridline-club' ); ?><span>→</span></a><a class="gl-text-link" href="#story"><?php esc_html_e( 'Why APEXIK', 'gridline-club' ); ?> ↘</a></div>
				<div class="gl-hero-proof"><div><strong>7</strong><span><?php esc_html_e( 'DROP 01', 'gridline-club' ); ?></span><small><?php esc_html_e( 'Launch products', 'gridline-club' ); ?></small></div><div><strong>$49</strong><span><?php esc_html_e( 'MAX', 'gridline-club' ); ?></span><small><?php esc_html_e( 'Everything under $50', 'gridline-club' ); ?></small></div><div><strong>0</strong><span><?php esc_html_e( 'LOGOS', 'gridline-club' ); ?></span><small><?php esc_html_e( 'Independent design system', 'gridline-club' ); ?></small></div></div>
			</div>
			<div class="gl-hero-visual">
				<div class="gl-hero-badge"><span>DROP</span><strong>01</strong></div>
				<img src="<?php echo esc_url( $theme . '/assets/images/products/apexik-box-polo.jpg' ); ?>" alt="<?php esc_attr_e( 'Box Box Stay Out racing radio polo', 'gridline-club' ); ?>">
				<div class="gl-hero-caption"><span><?php esc_html_e( 'Radio drop 01', 'gridline-club' ); ?></span><strong><?php esc_html_e( 'Box Box / Stay Out Polo', 'gridline-club' ); ?></strong><a href="<?php echo esc_url( $shop_url ); ?>">$44 · View</a></div>
			</div>
		</div>
	</section>

	<div class="gl-marquee" aria-label="Radio quote collection"><div><span>BOX BOX</span><i>◆</i><span>STAY OUT</span><i>◆</i><span>GP2 ENGINE</span><i>◆</i><span>SIMPLY LOVELY</span><i>◆</i><span>MUST BE THE WATER</span><i>◆</i><span>RADIO CHECK</span></div></div>

	<section class="gl-section gl-categories">
		<div class="gl-container">
			<div class="gl-section-heading"><div><p class="gl-eyebrow">01 / <?php esc_html_e( 'Choose your channel', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Radio moments, made useful.', 'gridline-club' ); ?></h2></div><a class="gl-text-link" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Shop everything', 'gridline-club' ); ?> →</a></div>
			<div class="gl-category-grid">
				<a class="gl-category-card gl-category-card--large" href="<?php echo esc_url( home_url( '/product-category/radio-apparel/' ) ); ?>"><img src="<?php echo esc_url( $theme . '/assets/images/products/apexik-gp2-hoodie.jpg' ); ?>" alt=""><span>01</span><div><p><?php esc_html_e( 'Radio apparel', 'gridline-club' ); ?></p><strong><?php esc_html_e( 'Wear the channel.', 'gridline-club' ); ?></strong></div></a>
				<a class="gl-category-card" href="<?php echo esc_url( home_url( '/product-category/drinkware/' ) ); ?>"><img src="<?php echo esc_url( $theme . '/assets/images/products/apexik-simply-tumbler.jpg' ); ?>" alt=""><span>02</span><div><p><?php esc_html_e( 'Drinkware', 'gridline-club' ); ?></p><strong><?php esc_html_e( 'For early starts and long races.', 'gridline-club' ); ?></strong></div></a>
				<a class="gl-category-card" href="<?php echo esc_url( home_url( '/product-category/race-day-gear/' ) ); ?>"><img src="<?php echo esc_url( $theme . '/assets/images/products/apexik-viewing-kit.jpg' ); ?>" alt=""><span>03</span><div><p><?php esc_html_e( 'Race day gear', 'gridline-club' ); ?></p><strong><?php esc_html_e( 'Carry less. Watch longer.', 'gridline-club' ); ?></strong></div></a>
			</div>
		</div>
	</section>

	<section class="gl-section gl-products-section">
		<div class="gl-container">
			<div class="gl-section-heading"><div><p class="gl-eyebrow">02 / <?php esc_html_e( 'Radio drop 01', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'The first seven messages.', 'gridline-club' ); ?></h2></div><p class="gl-heading-note"><?php esc_html_e( 'Authorized phrases, original signal graphics, and every product priced below $50.', 'gridline-club' ); ?></p></div>
			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<?php echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC" visibility="visible"]' ); ?>
			<?php else : ?>
				<div class="gl-product-placeholder"><p><?php esc_html_e( 'Activate WooCommerce and the APEXIK Starter plugin to display the product collection.', 'gridline-club' ); ?></p></div>
			<?php endif; ?>
		</div>
	</section>

	<section id="story" class="gl-story-split">
		<div class="gl-story-media"><img src="<?php echo esc_url( $theme . '/assets/images/products/apexik-radio-accessory-kit.jpg' ); ?>" alt="<?php esc_attr_e( 'APEXIK racing radio accessory gift kit', 'gridline-club' ); ?>"><div class="gl-story-stamp"><span><?php esc_html_e( 'Built from', 'gridline-club' ); ?></span><strong><?php esc_html_e( 'THE RADIO', 'gridline-club' ); ?></strong></div></div>
		<div class="gl-story-copy"><p class="gl-eyebrow">03 / <?php esc_html_e( 'Our point of view', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Not team merch.', 'gridline-club' ); ?><br><em><?php esc_html_e( 'Radio culture.', 'gridline-club' ); ?></em></h2><p class="gl-lead"><?php esc_html_e( 'We take authorized racing-radio phrases and rebuild them through Apexik waveforms, channel codes, signal blocks, and products fans can use every day.', 'gridline-club' ); ?></p><div class="gl-principles"><div><span>01</span><p><strong><?php esc_html_e( 'The phrase is the hero', 'gridline-club' ); ?></strong><?php esc_html_e( 'The moment stays recognizable without a team crest or driver name.', 'gridline-club' ); ?></p></div><div><span>02</span><p><strong><?php esc_html_e( 'Everything under $50', 'gridline-club' ); ?></strong><?php esc_html_e( 'Easy gifts, wearable references, and practical trackside gear.', 'gridline-club' ); ?></p></div><div><span>03</span><p><strong><?php esc_html_e( 'Independent by design', 'gridline-club' ); ?></strong><?php esc_html_e( 'No copied liveries, sponsor graphics, or official series branding.', 'gridline-club' ); ?></p></div></div><a class="gl-button gl-button--dark" href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php esc_html_e( 'Read our story', 'gridline-club' ); ?> <span>→</span></a></div>
	</section>

	<section class="gl-section gl-gift-guide">
		<div class="gl-container">
			<div class="gl-section-heading gl-section-heading--center"><div><p class="gl-eyebrow">04 / <?php esc_html_e( 'Gift guide', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Radio-ready gifts.', 'gridline-club' ); ?></h2></div></div>
			<div class="gl-gift-grid"><a href="<?php echo esc_url( add_query_arg( 'max_price', '25', $shop_url ) ); ?>"><span><?php esc_html_e( 'Under', 'gridline-club' ); ?></span><strong>$25</strong><small><?php esc_html_e( 'Mugs & small gifts', 'gridline-club' ); ?> →</small></a><a href="<?php echo esc_url( add_query_arg( 'max_price', '40', $shop_url ) ); ?>"><span><?php esc_html_e( 'Under', 'gridline-club' ); ?></span><strong>$40</strong><small><?php esc_html_e( 'Desk & travel', 'gridline-club' ); ?> →</small></a><a href="<?php echo esc_url( home_url( '/product-category/race-day-gear/' ) ); ?>"><span><?php esc_html_e( 'For the', 'gridline-club' ); ?></span><strong><?php esc_html_e( 'TRACKSIDE', 'gridline-club' ); ?></strong><small><?php esc_html_e( 'Viewing essentials', 'gridline-club' ); ?> →</small></a></div>
		</div>
	</section>

	<section class="gl-section gl-testimonials">
		<div class="gl-container"><div class="gl-section-heading"><div><p class="gl-eyebrow">05 / <?php esc_html_e( 'The radio archive', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'You heard every word.', 'gridline-club' ); ?></h2></div><p class="gl-heading-note"><?php esc_html_e( 'No names needed. If you know, you know.', 'gridline-club' ); ?></p></div><div class="gl-review-grid"><blockquote><div>CH // 14</div><p>“BOX BOX.”<br>“STAY OUT, STAY OUT.”</p><footer>STRATEGY REVERSAL <span>00:03</span></footer></blockquote><blockquote><div>CH // 05</div><p>“GP2 ENGINE.”</p><footer>RADIO UNFILTERED <span>00:01</span></footer></blockquote><blockquote><div>CH // 33</div><p>“SIMPLY LOVELY.”</p><footer>AFTER THE FLAG <span>00:02</span></footer></blockquote></div></div>
	</section>

	<section class="gl-newsletter-panel">
		<div class="gl-container gl-newsletter-panel-inner"><div><p class="gl-eyebrow">RADIO CHECK</p><h2><?php esc_html_e( 'Get the next quote before lights out.', 'gridline-club' ); ?></h2></div><?php echo gridline_newsletter_capture( 'home-email', __( 'Join the channel', 'gridline-club' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
	</section>
</main>
<?php get_footer(); ?>
