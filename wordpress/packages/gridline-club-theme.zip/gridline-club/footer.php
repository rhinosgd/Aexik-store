<?php /** @package GridlineClub */ ?>
<footer class="gl-footer">
	<div class="gl-container">
		<div class="gl-footer-main">
			<div class="gl-footer-brand">
				<a class="gl-brand gl-brand--light" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="gl-brand-mark">A</span><span class="gl-brand-type">APEXIK<span>RADIO GOODS</span></span></a>
				<p><?php esc_html_e( 'Racing radio phrases turned into apparel, gifts, desk gear, and trackside essentials.', 'gridline-club' ); ?></p>
			</div>
			<div><h3><?php esc_html_e( 'Shop', 'gridline-club' ); ?></h3><a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>">All products</a><a href="<?php echo esc_url( home_url( '/product-category/radio-apparel/' ) ); ?>">Radio apparel</a><a href="<?php echo esc_url( home_url( '/product-category/drinkware/' ) ); ?>">Drinkware</a><a href="<?php echo esc_url( home_url( '/product-category/race-day-gear/' ) ); ?>">Race day gear</a></div>
			<div><h3><?php esc_html_e( 'Help', 'gridline-club' ); ?></h3><a href="<?php echo esc_url( home_url( '/shipping-returns/' ) ); ?>">Shipping & returns</a><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">FAQ</a><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">Contact</a><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy</a><a href="<?php echo esc_url( home_url( '/terms-conditions/' ) ); ?>">Terms</a><a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>">Cookies</a></div>
			<div class="gl-footer-newsletter"><h3><?php esc_html_e( 'Join the formation lap', 'gridline-club' ); ?></h3><p><?php esc_html_e( 'New drops, race-weekend offers, no inbox clutter.', 'gridline-club' ); ?></p><?php echo gridline_newsletter_capture( 'footer-email', __( 'Join', 'gridline-club' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
		</div>
		<div class="gl-footer-bottom"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span><span><?php esc_html_e( 'Independent racing-radio culture. No team, driver, sponsor, or championship affiliation.', 'gridline-club' ); ?></span></div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
