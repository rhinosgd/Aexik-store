(() => {
  const toggle = document.querySelector('[data-menu-toggle]');
  const menu = document.querySelector('[data-menu]');
  const closeMenu = () => {
    if (!toggle || !menu) return;
    toggle.setAttribute('aria-expanded', 'false');
    menu.classList.remove('is-open');
    document.body.classList.remove('menu-open');
  };

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      menu.classList.toggle('is-open', !open);
      document.body.classList.toggle('menu-open', !open);
    });
    menu.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
  }

  const searchTrigger = document.querySelector('[data-search-open]');
  const searchDrawer = document.querySelector('[data-search-drawer]');
  const searchInput = searchDrawer?.querySelector('input[type="search"]');
  let returnFocus = null;

  const closeSearch = () => {
    if (!searchDrawer || searchDrawer.getAttribute('aria-hidden') === 'true') return;
    searchDrawer.setAttribute('aria-hidden', 'true');
    searchTrigger?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('search-open');
    returnFocus?.focus();
  };

  const openSearch = () => {
    if (!searchDrawer) return;
    closeMenu();
    returnFocus = document.activeElement;
    searchDrawer.setAttribute('aria-hidden', 'false');
    searchTrigger?.setAttribute('aria-expanded', 'true');
    document.body.classList.add('search-open');
    window.setTimeout(() => searchInput?.focus(), 40);
  };

  searchTrigger?.addEventListener('click', openSearch);
  searchDrawer?.querySelectorAll('[data-search-close]').forEach((button) => button.addEventListener('click', closeSearch));
  searchDrawer?.addEventListener('keydown', (event) => {
    if (event.key !== 'Tab') return;
    const controls = [...searchDrawer.querySelectorAll('button, a, input')].filter((item) => !item.disabled && item.offsetParent !== null);
    if (!controls.length) return;
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    closeSearch();
    closeMenu();
  });

  document.querySelectorAll('[data-accordion] button').forEach((button, index) => {
    const panel = button.nextElementSibling;
    if (!panel) return;
    const panelId = panel.id || `gridline-accordion-${index + 1}`;
    panel.id = panelId;
    button.setAttribute('aria-controls', panelId);
    panel.hidden = button.getAttribute('aria-expanded') !== 'true';
    button.addEventListener('click', () => {
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      panel.hidden = expanded;
    });
  });

})();
