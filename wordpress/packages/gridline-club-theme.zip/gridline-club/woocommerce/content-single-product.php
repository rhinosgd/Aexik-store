<?php
/**
 * Custom single product layout.
 *
 * @package GridlineClub
 */

defined( 'ABSPATH' ) || exit;
global $product;

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$id         = $product->get_id();
$subtitle   = gridline_product_meta( $id, 'subtitle', wp_strip_all_tags( $product->get_short_description() ) );
$eyebrow    = gridline_product_meta( $id, 'eyebrow', __( 'APEXIK radio goods', 'gridline-club' ) );
$benefits   = gridline_lines( gridline_product_meta( $id, 'benefits', "Original motorsport-inspired design\nGift-ready protective packaging\n30-day easy returns" ) );
$what       = gridline_product_meta( $id, 'what', wp_strip_all_tags( $product->get_description() ) );
$difference = gridline_product_meta( $id, 'difference', __( 'Designed as an object first and fan merchandise second: restrained graphics, tactile materials, and no borrowed team identity.', 'gridline-club' ) );
$materials  = gridline_product_meta( $id, 'materials', __( 'See product description', 'gridline-club' ) );
$dimensions = gridline_product_meta( $id, 'dimensions', __( 'See options above', 'gridline-club' ) );
$care       = gridline_product_meta( $id, 'care', __( 'Wipe clean with a soft, dry cloth', 'gridline-club' ) );
$dispatch   = gridline_product_meta( $id, 'dispatch', __( 'Usually dispatches in 2–4 business days', 'gridline-club' ) );
$faq_lines  = gridline_lines( gridline_product_meta( $id, 'faq', "Is this official team merchandise? | No. APEXIK is an independent racing-radio culture brand.\nWhen will my order ship? | Most orders dispatch within 2–4 business days. Tracking is emailed when your parcel leaves.\nCan I return it? | Yes. Unused products can be returned within 30 days of delivery." ) );
?>
<?php do_action( 'woocommerce_before_single_product' ); ?>
<article id="product-<?php the_ID(); ?>" <?php wc_product_class( 'gl-product-detail', $product ); ?>>
	<div class="gl-container gl-product-top">
		<div class="gl-product-gallery-wrap">
			<?php do_action( 'woocommerce_before_single_product_summary' ); ?>
		</div>
		<div class="gl-product-summary">
			<nav class="gl-breadcrumb" aria-label="Breadcrumb"><?php woocommerce_breadcrumb( array( 'delimiter' => '<span>/</span>' ) ); ?></nav>
			<p class="gl-kicker"><span></span><?php echo esc_html( $eyebrow ); ?></p>
			<?php woocommerce_template_single_rating(); ?>
			<h1 class="product_title entry-title"><?php the_title(); ?></h1>
			<?php if ( $subtitle ) : ?><p class="gl-product-subtitle"><?php echo esc_html( $subtitle ); ?></p><?php endif; ?>
			<ul class="gl-benefit-list">
				<?php foreach ( array_slice( $benefits, 0, 4 ) as $benefit ) : ?><li><span>✓</span><?php echo esc_html( $benefit ); ?></li><?php endforeach; ?>
			</ul>
			<div class="gl-buy-row">
				<?php woocommerce_template_single_price(); ?>
				<span class="gl-pay-note"><?php esc_html_e( 'Taxes calculated at checkout', 'gridline-club' ); ?></span>
			</div>
			<div class="gl-add-to-cart-wrap"><?php woocommerce_template_single_add_to_cart(); ?><?php if ( $product->is_type( 'variable' ) ) : ?><a class="gl-size-guide-link" href="<?php echo esc_url( home_url( '/size-guide/' ) ); ?>"><?php esc_html_e( 'View size guide', 'gridline-club' ); ?> →</a><?php endif; ?></div>
			<div class="gl-purchase-assurance"><div><span>↗</span><p><strong><?php esc_html_e( 'Tracked delivery', 'gridline-club' ); ?></strong><?php echo esc_html( $dispatch ); ?></p></div><div><span>↩</span><p><strong><?php esc_html_e( 'Easy returns', 'gridline-club' ); ?></strong><?php esc_html_e( '30 days from delivery', 'gridline-club' ); ?></p></div><div><span>◇</span><p><strong><?php esc_html_e( 'Gift-ready', 'gridline-club' ); ?></strong><?php esc_html_e( 'Protective, low-plastic packaging', 'gridline-club' ); ?></p></div></div>
			<div class="gl-product-meta"><?php woocommerce_template_single_meta(); ?></div>
		</div>
	</div>

	<section class="gl-trust-ribbon"><div class="gl-container"><div><span>01</span><strong><?php esc_html_e( 'AUTHORIZED PHRASE', 'gridline-club' ); ?></strong></div><div><span>02</span><strong><?php esc_html_e( 'ORIGINAL GRAPHICS', 'gridline-club' ); ?></strong></div><div><span>03</span><strong><?php esc_html_e( 'UNDER $50', 'gridline-club' ); ?></strong></div><div><span>04</span><strong><?php esc_html_e( 'NO TEAM LOGOS', 'gridline-club' ); ?></strong></div></div></section>

	<section class="gl-product-editorial gl-container">
		<div class="gl-section-heading"><div><p class="gl-eyebrow">01 / <?php esc_html_e( 'The object', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Built for the hours between races.', 'gridline-club' ); ?></h2></div></div>
		<div class="gl-editorial-grid"><div class="gl-editorial-media"><?php echo $product->get_image( 'gridline-hero' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><div class="gl-editorial-copy"><h3><?php esc_html_e( 'What it is', 'gridline-club' ); ?></h3><p><?php echo esc_html( $what ); ?></p><hr><h3><?php esc_html_e( 'What makes it different', 'gridline-club' ); ?></h3><p><?php echo esc_html( $difference ); ?></p></div></div>
	</section>

	<section class="gl-how-it-works">
		<div class="gl-container"><div class="gl-section-heading"><div><p class="gl-eyebrow">02 / <?php esc_html_e( 'Why it works', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'The details do the talking.', 'gridline-club' ); ?></h2></div></div><div class="gl-feature-grid"><div><span class="gl-feature-icon">⌁</span><h3><?php esc_html_e( 'A quiet reference', 'gridline-club' ); ?></h3><p><?php esc_html_e( 'Recognizable to people who follow racing, considered enough to live anywhere.', 'gridline-club' ); ?></p></div><div><span class="gl-feature-icon">◎</span><h3><?php esc_html_e( 'Material first', 'gridline-club' ); ?></h3><p><?php esc_html_e( 'Selected for feel, weight, finish, and how it handles everyday use.', 'gridline-club' ); ?></p></div><div><span class="gl-feature-icon">↗</span><h3><?php esc_html_e( 'Ready to give', 'gridline-club' ); ?></h3><p><?php esc_html_e( 'A complete object and a considered unboxing—no extra wrapping required.', 'gridline-club' ); ?></p></div></div></div>
	</section>

	<section class="gl-spec-section gl-container">
		<div class="gl-section-heading"><div><p class="gl-eyebrow">03 / <?php esc_html_e( 'Specification', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Everything before checkout.', 'gridline-club' ); ?></h2></div></div>
		<div class="gl-spec-grid"><div><span><?php esc_html_e( 'Materials', 'gridline-club' ); ?></span><strong><?php echo esc_html( $materials ); ?></strong></div><div><span><?php esc_html_e( 'Size / fit', 'gridline-club' ); ?></span><strong><?php echo esc_html( $dimensions ); ?></strong></div><div><span><?php esc_html_e( 'Care', 'gridline-club' ); ?></span><strong><?php echo esc_html( $care ); ?></strong></div><div><span><?php esc_html_e( 'Dispatch', 'gridline-club' ); ?></span><strong><?php echo esc_html( $dispatch ); ?></strong></div></div>
	</section>

	<section class="gl-compare-section"><div class="gl-container"><div class="gl-section-heading"><div><p class="gl-eyebrow">04 / <?php esc_html_e( 'Our standard', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'Radio culture, reworked.', 'gridline-club' ); ?></h2></div></div><div class="gl-compare"><div class="gl-compare-card gl-compare-card--brand"><p>APEXIK</p><ul><li><span>✓</span><?php esc_html_e( 'Authorized radio phrases', 'gridline-club' ); ?></li><li><span>✓</span><?php esc_html_e( 'Original signal graphics', 'gridline-club' ); ?></li><li><span>✓</span><?php esc_html_e( 'Useful, under-$50 products', 'gridline-club' ); ?></li><li><span>✓</span><?php esc_html_e( 'No copied team identity', 'gridline-club' ); ?></li></ul></div><div class="gl-compare-card"><p><?php esc_html_e( 'Typical replica merch', 'gridline-club' ); ?></p><ul><li><span>×</span><?php esc_html_e( 'Logo does all the work', 'gridline-club' ); ?></li><li><span>×</span><?php esc_html_e( 'Built for a single moment', 'gridline-club' ); ?></li><li><span>×</span><?php esc_html_e( 'Generic blank and packaging', 'gridline-club' ); ?></li><li><span>×</span><?php esc_html_e( 'Minimal product detail', 'gridline-club' ); ?></li></ul></div></div></div></section>

	<section class="gl-faq-section gl-container"><div class="gl-section-heading"><div><p class="gl-eyebrow">05 / FAQ</p><h2><?php esc_html_e( 'Before you ask the pit wall.', 'gridline-club' ); ?></h2></div></div><div class="gl-accordion" data-accordion>
		<?php foreach ( $faq_lines as $index => $line ) : $parts = array_map( 'trim', explode( '|', $line, 2 ) ); if ( 2 !== count( $parts ) ) { continue; } ?>
			<div class="gl-accordion-item"><button type="button" aria-expanded="<?php echo 0 === $index ? 'true' : 'false'; ?>"><span><?php echo esc_html( $parts[0] ); ?></span><i>+</i></button><div class="gl-accordion-panel"><p><?php echo esc_html( $parts[1] ); ?></p></div></div>
		<?php endforeach; ?>
	</div></section>

	<section class="gl-product-reviews gl-container"><div class="gl-section-heading"><div><p class="gl-eyebrow">06 / <?php esc_html_e( 'Reviews', 'gridline-club' ); ?></p><h2><?php esc_html_e( 'From people on the grid.', 'gridline-club' ); ?></h2></div></div><?php comments_template(); ?></section>

	<section class="gl-related gl-container"><?php woocommerce_output_related_products( array( 'posts_per_page' => 4, 'columns' => 4 ) ); ?></section>
</article>
<?php do_action( 'woocommerce_after_single_product' ); ?>
