=== APEXIK Story Engine ===
Contributors: apexik
Requires at least: 6.6
Requires PHP: 8.1
Stable tag: 1.0.0

Persistent content model for APEXIK Race Moments and product-story relationships.

== Description ==

Registers Race Moments and shared Event, Championship, Story Type, Team and Driver taxonomies.
Adds native metadata panels for story source/rights records and WooCommerce product storytelling.
Includes an explicit Tools > APEXIK Setup seeder for draft placeholder content.

The plugin never auto-seeds on activation and never writes Printful mapping data.
