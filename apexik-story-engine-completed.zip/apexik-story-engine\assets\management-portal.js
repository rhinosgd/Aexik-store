(()=>{
  'use strict';
  const body=document.body;
  const menu=document.querySelector('[data-control-menu]');
  const collapse=document.querySelector('[data-control-collapse]');
  const nav=document.querySelector('[data-control-nav]');
  const close=()=>{nav?.classList.remove('is-open');menu?.setAttribute('aria-expanded','false')};
  const setCollapsed=collapsed=>{
    body.classList.toggle('apx-control-collapsed',collapsed);
    collapse?.setAttribute('aria-expanded',String(!collapsed));
    if(collapse){const label=collapsed?'展开侧栏':'收起侧栏';collapse.setAttribute('aria-label',label);collapse.title=label}
  };
  let stored=false;
  try{stored=window.localStorage.getItem('apx_control_sidebar')==='collapsed'}catch(error){stored=false}
  setCollapsed(stored);
  collapse?.addEventListener('click',()=>{
    const next=!body.classList.contains('apx-control-collapsed');
    setCollapsed(next);
    try{window.localStorage.setItem('apx_control_sidebar',next?'collapsed':'expanded')}catch(error){}
  });
  menu?.addEventListener('click',()=>{const open=!nav?.classList.contains('is-open');nav?.classList.toggle('is-open',open);menu.setAttribute('aria-expanded',String(open))});
  nav?.querySelectorAll('a').forEach(link=>link.addEventListener('click',close));
  document.addEventListener('keydown',event=>{if(event.key==='Escape')close()});
  document.querySelectorAll('.apx-control-form,.apx-control-row form,.apx-control-inquiry form,.apx-inquiries form').forEach(form=>form.addEventListener('submit',()=>{if(!form.reportValidity())return;const button=form.querySelector('button[type="submit"]');if(button){button.disabled=true;button.dataset.label=button.textContent;button.textContent='处理中…'}}));
})();

(()=>{
  if(new URLSearchParams(window.location.search).get('view')!=='orders') return;
  const heading=[...document.querySelectorAll('.apx-control-panel__head h2')].find((el)=>el.textContent.includes('订单'));
  const head=heading?.closest('.apx-control-panel__head');
  if(!head || head.querySelector('[data-export-orders]')) return;
  const link=document.createElement('a');
  link.dataset.exportOrders='1';
  link.className='apx-button';
  link.href=`${window.location.origin}/wp-admin/admin-post.php?action=apx_portal_export_orders&_wpnonce=${encodeURIComponent(document.querySelector('input[name="_wpnonce"]')?.value||'')}`;
  link.textContent='Export CSV';
  head.appendChild(link);
})();

// Keep the product editor usable on long forms without changing its fields or data flow.
(()=>{
  const form=document.querySelector('.apx-control-form[action*="admin-post.php"] input[name="product_id"]')?.form;
  if(!form || !form.querySelector('input[name="action"][value="apx_portal_save_product"]')) return;
  const panel=form.closest('.apx-control-panel');
  if(!panel || panel.querySelector('.apx-product-details')) return;
  const details=document.createElement('details');
  details.className='apx-product-details';
  details.open=true;
  details.style.marginBottom='18px';
  details.style.borderBottom='1px solid #d5d0c8';
  const summary=document.createElement('summary');
  summary.style.cursor='pointer';
  summary.style.display='flex';
  summary.style.justifyContent='space-between';
  summary.style.padding='12px 0 18px';
  summary.innerHTML='<span><strong>Product editor</strong><small>Product details, variants, media and SEO</small></span><i aria-hidden="true">＋</i>';
  panel.insertBefore(details,form);
  details.appendChild(summary);
  details.appendChild(form);
  const styleField=form.querySelector('input[name="style"]');
  const sizeField=form.querySelector('input[name="size"]');
  if(styleField && sizeField){
    const addMulti=(source,name,label,help)=>{
      const wrap=document.createElement('label'); wrap.className='apx-field apx-field--wide';
      wrap.innerHTML=`<span>${label}</span><input name="${name}" value="${source.value.replace(/"/g,'&quot;')}" placeholder="Comma-separated values"><small>${help}</small>`;
      source.closest('.apx-field')?.after(wrap);
    };
    addMulti(styleField,'style_values','Style options','Use commas for multiple options, for example Style A, Style B.');
    addMulti(sizeField,'size_values','Size options','Use commas for multiple sizes, for example 600 × 300 mm, 800 × 300 mm.');
  }
})();
