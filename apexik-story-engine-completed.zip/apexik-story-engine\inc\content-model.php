<?php
/**
 * Persistent post types, taxonomies and metadata.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_register_content_model() {
	register_post_type( 'apexik_moment', array(
		'labels' => array(
			'name'          => __( 'Race Moments', 'apexik-story-engine' ),
			'singular_name' => __( 'Race Moment', 'apexik-story-engine' ),
			'add_new_item'  => __( 'Add Race Moment', 'apexik-story-engine' ),
			'edit_item'     => __( 'Edit Race Moment', 'apexik-story-engine' ),
		),
		'public'       => true,
		'show_in_rest' => true,
		'has_archive'  => 'race-moments',
		'rewrite'      => array( 'slug' => 'race-moments', 'with_front' => false ),
		'menu_icon'    => 'dashicons-flag',
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'author' ),
	) );

	register_post_type( 'apexik_inquiry', array(
		'labels' => array(
			'name'          => __( 'Customer Inquiries', 'apexik-story-engine' ),
			'singular_name' => __( 'Customer Inquiry', 'apexik-story-engine' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => false,
		'menu_icon'    => 'dashicons-email-alt2',
		'supports'     => array( 'title', 'editor' ),
		'capability_type' => 'post',
	) );

	$taxonomies = array(
		'apx_event'       => array( 'Event', 'Events', 'event' ),
		'apx_championship'=> array( 'Championship', 'Championships', 'championship' ),
		'apx_story_type'  => array( 'Story Type', 'Story Types', 'story-type' ),
		'apx_team'        => array( 'Team', 'Teams', 'team' ),
		'apx_driver'      => array( 'Driver', 'Drivers', 'driver' ),
	);
	foreach ( $taxonomies as $taxonomy => $labels ) {
		register_taxonomy( $taxonomy, array( 'apexik_moment', 'product' ), array(
			'labels' => array( 'name' => __( $labels[1], 'apexik-story-engine' ), 'singular_name' => __( $labels[0], 'apexik-story-engine' ) ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText
			'public'            => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => array( 'slug' => $labels[2], 'with_front' => false ),
		) );
	}

	$moment_meta = array(
		'_apx_event_date'          => 'string',
		'_apx_race_round'          => 'integer',
		'_apx_radio_quote'         => 'string',
		'_apx_source_title'        => 'string',
		'_apx_source_url'          => 'string',
		'_apx_reference_timestamp' => 'string',
		'_apx_related_products'    => 'string',
		'_apx_featured_until'      => 'string',
		'_apx_editorial_status'    => 'string',
		'_apx_rights_status'       => 'string',
	);
	foreach ( $moment_meta as $key => $type ) {
		register_post_meta( 'apexik_moment', $key, array(
			'type'              => $type,
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'integer' === $type ? 'absint' : 'sanitize_text_field',
			'auth_callback'     => function() { return current_user_can( 'edit_posts' ); },
		) );
	}

	foreach ( array( '_apx_story_summary', '_apx_related_moments', '_apx_design_reference', '_apx_production_notes', '_apx_care_notes', '_apx_provider' ) as $key ) {
		register_post_meta( 'product', $key, array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_textarea_field',
			'auth_callback'     => function() { return current_user_can( 'edit_products' ); },
		) );
	}
}
add_action( 'init', 'apx_register_content_model' );

function apx_register_story_post_states( $states, $post ) {
	if ( 'product' === $post->post_type && get_post_meta( $post->ID, '_apx_is_placeholder', true ) ) {
		$states['apx-placeholder'] = __( 'APEXIK placeholder — do not sync', 'apexik-story-engine' );
	}
	return $states;
}
add_filter( 'display_post_states', 'apx_register_story_post_states', 10, 2 );
