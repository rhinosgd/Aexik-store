<?php
/**
 * Explicit, repeatable placeholder content seeder.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_setup_menu() {
	add_management_page( __( 'APEXIK Setup', 'apexik-story-engine' ), __( 'APEXIK Setup', 'apexik-story-engine' ), 'manage_options', 'apexik-setup', 'apx_setup_page' );
}
add_action( 'admin_menu', 'apx_setup_menu' );

function apx_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( isset( $_POST['apx_seed_action'] ) ) {
		check_admin_referer( 'apx_seed_content' );
		$action = sanitize_key( wp_unslash( $_POST['apx_seed_action'] ) );
		if ( 'seed' === $action ) {
			$result = apx_seed_placeholder_content();
			add_settings_error( 'apx_setup', 'seeded', sprintf( __( 'Placeholder structure created or updated: %d records.', 'apexik-story-engine' ), $result ), 'success' );
		} elseif ( 'reset' === $action ) {
			$result = apx_reset_placeholder_content();
			add_settings_error( 'apx_setup', 'reset', sprintf( __( 'Removed %d APEXIK placeholder records. Human-authored content was untouched.', 'apexik-story-engine' ), $result ), 'success' );
		}
	}
	settings_errors( 'apx_setup' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'APEXIK structure setup', 'apexik-story-engine' ); ?></h1>
		<p><?php esc_html_e( 'This tool creates draft placeholder content only. It never syncs products to Printful and never deletes content without an APEXIK seed key.', 'apexik-story-engine' ); ?></p>
		<form method="post">
			<?php wp_nonce_field( 'apx_seed_content' ); ?>
			<p><button class="button button-primary" name="apx_seed_action" value="seed"><?php esc_html_e( 'Create / update placeholder structure', 'apexik-story-engine' ); ?></button></p>
			<p><button class="button" name="apx_seed_action" value="reset" onclick="return confirm('<?php echo esc_js( __( 'Remove only APEXIK placeholder records?', 'apexik-story-engine' ) ); ?>')"><?php esc_html_e( 'Remove placeholder records', 'apexik-story-engine' ); ?></button></p>
		</form>
	</div>
	<?php
}

function apx_seed_post( $type, $key, $title, $content = '', $status = 'draft' ) {
	$existing = get_posts( array( 'post_type' => $type, 'post_status' => 'any', 'meta_key' => '_apx_seed_key', 'meta_value' => $key, 'posts_per_page' => 1, 'fields' => 'ids' ) );
	$data = array( 'post_type' => $type, 'post_title' => $title, 'post_content' => $content, 'post_status' => $status );
	if ( $existing ) {
		$data['ID'] = $existing[0];
	}
	$id = wp_insert_post( wp_slash( $data ) );
	if ( ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_apx_seed_key', $key );
	}
	return is_wp_error( $id ) ? 0 : $id;
}

function apx_seed_product_asset( $product_id, $filename, $title ) {
	$source = get_stylesheet_directory() . '/assets/images/' . $filename;
	$existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_apx_seed_asset', 'meta_value' => $filename, 'posts_per_page' => 1, 'fields' => 'ids' ) );
	if ( $existing ) {
		return (int) $existing[0];
	}
	if ( ! $product_id || ! file_exists( $source ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( $source );
	if ( ! $tmp || ! copy( $source, $tmp ) ) {
		return 0;
	}
	$file = array( 'name' => $filename, 'tmp_name' => $tmp );
	$attachment_id = media_handle_sideload( $file, $product_id, $title );
	if ( is_wp_error( $attachment_id ) ) {
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return 0;
	}
	update_post_meta( $attachment_id, '_apx_seed_asset', $filename );
	return (int) $attachment_id;
}

function apx_seed_product_images( $product_id ) {
	$main_id = apx_seed_product_asset( $product_id, 'desk-mat-abu-dhabi-2021-artwork.png', 'Abu Dhabi 2021 — Lap 58 desk mat artwork' );
	if ( $main_id ) {
		set_post_thumbnail( $product_id, $main_id );
	}
	$gallery_ids = array();
	foreach ( array(
		'desk-mat-abu-dhabi-2021-angle.png' => 'Abu Dhabi 2021 — Lap 58 desk mat studio angle',
		'desk-mat-abu-dhabi-2021-edge.png' => 'Abu Dhabi 2021 — Lap 58 desk mat stitched edge',
		'desk-mat-abu-dhabi-2021-lifestyle.png' => 'Abu Dhabi 2021 — Lap 58 desk mat lifestyle view',
	) as $filename => $title ) {
		$attachment_id = apx_seed_product_asset( $product_id, $filename, $title );
		if ( $attachment_id ) {
			$gallery_ids[] = $attachment_id;
		}
	}
	update_post_meta( $product_id, '_product_image_gallery', implode( ',', $gallery_ids ) );
}

function apx_seed_placeholder_content() {
	$count = 0;
	$pages = array(
		'about' => 'About APEXIK', 'contact' => 'Contact', 'faq' => 'FAQ', 'shipping' => 'Shipping & Delivery', 'returns' => 'Returns', 'size-guide' => 'Size Guide', 'terms' => 'Terms & Conditions', 'privacy' => 'Privacy', 'rights-and-sources' => 'Rights & Sources',
	);
	foreach ( $pages as $slug => $title ) {
		$count += apx_seed_post( 'page', 'page-' . $slug, $title, '<!-- wp:paragraph --><p>Placeholder page. Replace with approved production copy before launch.</p><!-- /wp:paragraph -->', 'draft' ) ? 1 : 0;
	}

	foreach ( array( 'Pit Wall', 'Team Radio', 'Driver Talk', 'Paddock Review' ) as $term ) {
		$inserted = term_exists( $term, 'apx_story_type' );
		if ( ! $inserted ) {
			$inserted = wp_insert_term( $term, 'apx_story_type' );
		}
		if ( ! is_wp_error( $inserted ) ) {
			$term_id = is_array( $inserted ) ? $inserted['term_id'] : $inserted;
			update_term_meta( $term_id, '_apx_seed_key', 'story-' . sanitize_title( $term ) );
			$count++;
		}
	}

	$moments = array(
		'undercut-window' => array( 'The Undercut Window', '<!-- wp:heading --><h2>What happened</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Placeholder race report: document the decision point between traffic, tyre life and clean air.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Why it mattered</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Explain the strategic consequence and the fan discussion using approved sources.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>From story to product</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Show how the timeline becomes an original APEXIK visual system.</p><!-- /wp:paragraph -->', 'Pit Wall' ),
		'hold-position'   => array( 'Hold Position?', '<!-- wp:heading --><h2>What happened</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Placeholder race report: set out the radio exchange and the running order around it.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Why it mattered</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Separate verified context from fan interpretation before publishing.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>From story to product</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Translate the rhythm of the exchange into a licensed graphic composition.</p><!-- /wp:paragraph -->', 'Team Radio' ),
		'box-this-lap'    => array( 'Box This Lap', '<!-- wp:heading --><h2>What happened</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Placeholder race report: describe the pit-wall call and the crew sequence.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Why it mattered</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Explain the timing window and the outcome without inventing race facts.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>From story to product</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Map the call, lights and stop sequence into the final artwork.</p><!-- /wp:paragraph -->', 'Paddock Review' ),
		'tyres-are-gone'  => array( 'Tyres Are Gone', '<!-- wp:heading --><h2>What happened</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Placeholder race report: compare the approved radio line with the timing context.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Why it mattered</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Explain why the contrast became memorable to fans.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>From story to product</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Turn the contrast into an original visual without copying official merchandise.</p><!-- /wp:paragraph -->', 'Driver Talk' ),
	);
	$moment_ids = array();
	foreach ( $moments as $key => $moment ) {
		$id = apx_seed_post( 'apexik_moment', 'moment-' . $key, $moment[0], $moment[1], 'draft' );
		if ( $id ) {
			$moment_ids[] = $id;
			wp_set_object_terms( $id, $moment[2], 'apx_story_type' );
			update_post_meta( $id, '_apx_rights_status', 'draft' );
			$count++;
		}
	}

	foreach ( array(
		'journal-making-desk-mat' => 'Inside the making of a race-story desk mat',
		'journal-radio-line'      => 'Why the smallest radio line can hold the biggest story',
		'journal-source-sample'   => 'From source approval to the first product sample',
	) as $key => $title ) {
		$count += apx_seed_post( 'post', $key, $title, 'Placeholder journal article. Replace with approved editorial copy before launch.', 'draft' ) ? 1 : 0;
	}

	foreach ( array( 'Desk Mats', 'T-Shirts', 'Stickers', 'Keychains', 'Curated Finds' ) as $category ) {
		if ( taxonomy_exists( 'product_cat' ) && ! term_exists( $category, 'product_cat' ) ) {
			$term = wp_insert_term( $category, 'product_cat' );
			if ( ! is_wp_error( $term ) ) {
				update_term_meta( $term['term_id'], '_apx_seed_key', 'product-cat-' . sanitize_title( $category ) );
			}
		}
	}

	if ( post_type_exists( 'product' ) ) {
		$products = array( 'Abu Dhabi 2021 — Lap 58 Desk Mat', 'Hold Position? T-Shirt', 'Box This Lap Sticker', 'One Lap Too Late Keychain', 'Late Call, Perfect Gap Desk Mat', 'Tyres Are Gone T-Shirt', 'Sector Delta Sticker Set', 'Pit Window Keychain', 'Radio Check Desk Mat', 'Plan B T-Shirt', 'Track Limits Sticker', 'Formation Lap Keychain' );
		$category_names = array( 'Desk Mats', 'T-Shirts', 'Stickers', 'Keychains' );
		$story_names = array( 'Pit Wall', 'Team Radio', 'Paddock Review', 'Driver Talk' );
		$product_ids = array();
		foreach ( $products as $index => $title ) {
			$is_featured_desk_mat = 0 === $index;
			$content = $is_featured_desk_mat ? 'Licensed 600 × 300 mm desk mat artwork. Style A. Connect the final Printful SKU before publishing.' : 'Placeholder product. Configure the real Printful product and variants before publishing.';
			$id = apx_seed_post( 'product', 'product-' . sanitize_title( $title ), $title, $content, 'draft' );
			if ( $id ) {
				$product_ids[] = $id;
				update_post_meta( $id, '_apx_is_placeholder', '1' );
				update_post_meta( $id, '_apx_provider', 'Printful — not connected' );
				update_post_meta( $id, '_price', 29 + ( $index % 3 ) * 5 );
				update_post_meta( $id, '_regular_price', 29 + ( $index % 3 ) * 5 );
				wp_set_object_terms( $id, $category_names[ $index % 4 ], 'product_cat' );
				wp_set_object_terms( $id, $story_names[ $index % 4 ], 'apx_story_type' );
				if ( $is_featured_desk_mat ) {
					update_post_meta( $id, '_apx_design_reference', 'Style A · 600 × 300 mm · uploaded licensed artwork' );
					apx_seed_product_images( $id );
				}
				if ( class_exists( 'WC_Product_Variable' ) ) {
					wp_set_object_terms( $id, 'variable', 'product_type' );
					$product = new WC_Product_Variable( $id );
					$attributes = array();
					$styles = $is_featured_desk_mat ? array( 'Style A' ) : array( 'Timeline', 'Radio Transcript' );
					$sizes  = $is_featured_desk_mat ? array( '600 × 300 mm' ) : array( '600 × 300 mm', '800 × 300 mm' );
					foreach ( array( 'Style' => $styles, 'Size' => $sizes ) as $name => $options ) {
						$attribute = new WC_Product_Attribute();
						$attribute->set_name( $name );
						$attribute->set_options( $options );
						$attribute->set_visible( true );
						$attribute->set_variation( true );
						$attributes[] = $attribute;
					}
					$product->set_attributes( $attributes );
					$product->save();
					foreach ( $styles as $style ) {
						foreach ( $sizes as $size ) {
							$variation_key = 'variation-' . $id . '-' . sanitize_title( $style . '-' . $size );
							$existing_variation = get_posts( array( 'post_type' => 'product_variation', 'post_status' => 'any', 'post_parent' => $id, 'meta_key' => '_apx_seed_key', 'meta_value' => $variation_key, 'posts_per_page' => 1, 'fields' => 'ids' ) );
							$variation = $existing_variation ? new WC_Product_Variation( $existing_variation[0] ) : new WC_Product_Variation();
							$variation->set_parent_id( $id );
							$variation->set_status( 'publish' );
							$variation->set_regular_price( (string) ( 29 + ( $index % 3 ) * 5 ) );
							$variation->set_attributes( array( 'style' => sanitize_title( $style ), 'size' => sanitize_title( $size ) ) );
							$variation_id = $variation->save();
							update_post_meta( $variation_id, '_apx_seed_key', $variation_key );
						}
					}
				}
				$count++;
			}
		}
		foreach ( $moment_ids as $index => $moment_id ) {
			$connected = array_slice( $product_ids, $index * 3, 3 );
			update_post_meta( $moment_id, '_apx_related_products', implode( ',', $connected ) );
			foreach ( $connected as $product_id ) {
				update_post_meta( $product_id, '_apx_related_moments', (string) $moment_id );
			}
		}
	}
	return $count;
}

function apx_reset_placeholder_content() {
	$count = 0;
	$posts = get_posts( array( 'post_type' => 'any', 'post_status' => 'any', 'meta_key' => '_apx_seed_key', 'posts_per_page' => -1, 'fields' => 'ids' ) );
	foreach ( $posts as $post_id ) {
		if ( wp_delete_post( $post_id, true ) ) {
			$count++;
		}
	}
	foreach ( array( 'apx_story_type', 'product_cat' ) as $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			continue;
		}
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'meta_key' => '_apx_seed_key' ) );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( ! is_wp_error( wp_delete_term( $term->term_id, $taxonomy ) ) ) {
					$count++;
				}
			}
		}
	}
	return $count;
}
