<?php
/**
 * Guard rails around external integrations.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_exclude_placeholders_from_catalog( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( isset( $query->query_vars['post_type'] ) && 'product' === $query->query_vars['post_type'] ) {
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = array( 'key' => '_apx_is_placeholder', 'compare' => 'NOT EXISTS' );
		$query->set( 'meta_query', $meta_query );
	}
}
add_action( 'pre_get_posts', 'apx_exclude_placeholders_from_catalog' );

function apx_enforce_publication_guards( $data, $postarr ) {
	if ( 'publish' !== $data['post_status'] ) {
		return $data;
	}
	$post_id = isset( $postarr['ID'] ) ? absint( $postarr['ID'] ) : 0;
	if ( 'product' === $data['post_type'] && $post_id && get_post_meta( $post_id, '_apx_is_placeholder', true ) ) {
		$data['post_status'] = 'draft';
		set_transient( 'apx_publication_guard_' . get_current_user_id(), __( 'APEXIK kept the placeholder product as Draft. Replace its content and remove the placeholder flag before any Printful sync.', 'apexik-story-engine' ), 60 );
	}
	if ( 'apexik_moment' === $data['post_type'] ) {
		$status = isset( $_POST['_apx_rights_status'] ) ? sanitize_key( wp_unslash( $_POST['_apx_rights_status'] ) ) : ( $post_id ? get_post_meta( $post_id, '_apx_rights_status', true ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$source = isset( $_POST['_apx_source_url'] ) ? esc_url_raw( wp_unslash( $_POST['_apx_source_url'] ) ) : ( $post_id ? get_post_meta( $post_id, '_apx_source_url', true ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! in_array( $status, array( 'rights-approved', 'ready' ), true ) || ! $source ) {
			$data['post_status'] = 'pending';
			set_transient( 'apx_publication_guard_' . get_current_user_id(), __( 'APEXIK changed this Race Moment to Pending. A source URL and Rights approved/Ready status are required before publication.', 'apexik-story-engine' ), 60 );
		}
	}
	return $data;
}
add_filter( 'wp_insert_post_data', 'apx_enforce_publication_guards', 20, 2 );

function apx_publication_guard_notice() {
	$key = 'apx_publication_guard_' . get_current_user_id();
	$message = get_transient( $key );
	if ( ! $message ) {
		return;
	}
	delete_transient( $key );
	echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
}
add_action( 'admin_notices', 'apx_publication_guard_notice' );

function apx_hide_placeholder_products( $visible, $product_id ) {
	return get_post_meta( $product_id, '_apx_is_placeholder', true ) ? false : $visible;
}
add_filter( 'woocommerce_product_is_visible', 'apx_hide_placeholder_products', 10, 2 );

function apx_block_placeholder_add_to_cart( $passed, $product_id ) {
	if ( get_post_meta( $product_id, '_apx_is_placeholder', true ) ) {
		wc_add_notice( __( 'This APEXIK placeholder cannot be purchased or sent to fulfilment.', 'apexik-story-engine' ), 'error' );
		return false;
	}
	return $passed;
}
add_filter( 'woocommerce_add_to_cart_validation', 'apx_block_placeholder_add_to_cart', 10, 2 );

function apx_hide_placeholders_from_woocommerce_rest( $args ) {
	$meta_query   = isset( $args['meta_query'] ) ? (array) $args['meta_query'] : array();
	$meta_query[] = array( 'key' => '_apx_is_placeholder', 'compare' => 'NOT EXISTS' );
	$args['meta_query'] = $meta_query;
	return $args;
}
add_filter( 'woocommerce_rest_product_object_query', 'apx_hide_placeholders_from_woocommerce_rest' );

function apx_block_placeholder_rest_lookup( $result, $server, $request ) {
	$route = $request->get_route();
	if ( preg_match( '#^/wc/v[0-9]+/products/([0-9]+)(?:/|$)#', $route, $matches ) && get_post_meta( absint( $matches[1] ), '_apx_is_placeholder', true ) ) {
		return new WP_Error( 'apx_placeholder_product', __( 'APEXIK placeholder products are excluded from fulfilment API access.', 'apexik-story-engine' ), array( 'status' => 404 ) );
	}
	return $result;
}
add_filter( 'rest_pre_dispatch', 'apx_block_placeholder_rest_lookup', 10, 3 );

function apx_rank_math_moment_schema( $data, $jsonld ) {
	if ( ! is_singular( 'apexik_moment' ) ) {
		return $data;
	}
	$data['apexik_story'] = array(
		'@type'         => 'Article',
		'headline'      => get_the_title(),
		'datePublished' => get_the_date( DATE_W3C ),
		'dateModified'  => get_the_modified_date( DATE_W3C ),
		'description'   => get_the_excerpt(),
	);
	return $data;
}
add_filter( 'rank_math/json_ld', 'apx_rank_math_moment_schema', 20, 2 );

function apx_admin_integration_notice() {
	if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'get_current_screen' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || 'tools_page_apexik-setup' !== $screen->id ) {
		return;
	}
	$checks = array(
		'WooCommerce'                    => class_exists( 'WooCommerce' ),
		'Printful Integration for Woo'   => defined( 'PRINTFUL_VERSION' ) || class_exists( 'Printful_Integration' ),
		'Rank Math'                      => defined( 'RANK_MATH_VERSION' ),
		'Polylang for WooCommerce'       => defined( 'PLLWC_VERSION' ),
	);
	echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'Integration readiness:', 'apexik-story-engine' ) . '</strong></p><ul>';
	foreach ( $checks as $name => $active ) {
		echo '<li>' . esc_html( $name ) . ': ' . esc_html( $active ? __( 'active', 'apexik-story-engine' ) : __( 'not detected', 'apexik-story-engine' ) ) . '</li>';
	}
	echo '</ul></div>';
}
add_action( 'admin_notices', 'apx_admin_integration_notice' );
