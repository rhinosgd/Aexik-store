<?php
/**
 * Native metadata UI. ACF Pro can replace this layer later without changing stored keys.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_add_meta_boxes() {
	add_meta_box( 'apx-moment-source', __( 'Story, source and rights', 'apexik-story-engine' ), 'apx_render_moment_meta_box', 'apexik_moment', 'normal', 'high' );
	add_meta_box( 'apx-product-story', __( 'APEXIK story layer', 'apexik-story-engine' ), 'apx_render_product_meta_box', 'product', 'normal', 'default' );
}
add_action( 'add_meta_boxes', 'apx_add_meta_boxes' );

function apx_field( $post_id, $key, $label, $type = 'text', $description = '' ) {
	$value = get_post_meta( $post_id, $key, true );
	?>
	<p class="apx-admin-field">
		<label for="<?php echo esc_attr( $key ); ?>"><strong><?php echo esc_html( $label ); ?></strong></label><br>
		<?php if ( 'textarea' === $type ) : ?>
			<textarea class="widefat" rows="4" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
		<?php elseif ( 'select' === $type ) : ?>
			<select class="widefat" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>">
				<?php foreach ( array( 'draft' => 'Draft', 'source-checked' => 'Source checked', 'rights-approved' => 'Rights approved', 'ready' => 'Ready to publish' ) as $option => $name ) : ?>
					<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $value, $option ); ?>><?php echo esc_html( $name ); ?></option>
				<?php endforeach; ?>
			</select>
		<?php else : ?>
			<input class="widefat" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" type="<?php echo esc_attr( $type ); ?>" value="<?php echo esc_attr( $value ); ?>">
		<?php endif; ?>
		<?php if ( $description ) : ?><span class="description"><?php echo esc_html( $description ); ?></span><?php endif; ?>
	</p>
	<?php
}

function apx_render_moment_meta_box( $post ) {
	wp_nonce_field( 'apx_save_story_meta', 'apx_story_nonce' );
	apx_field( $post->ID, '_apx_event_date', __( 'Event date', 'apexik-story-engine' ), 'date' );
	apx_field( $post->ID, '_apx_race_round', __( 'Race round', 'apexik-story-engine' ), 'number' );
	apx_field( $post->ID, '_apx_radio_quote', __( 'Licensed radio line / hook', 'apexik-story-engine' ), 'textarea' );
	apx_field( $post->ID, '_apx_source_title', __( 'Source title', 'apexik-story-engine' ) );
	apx_field( $post->ID, '_apx_source_url', __( 'Source URL', 'apexik-story-engine' ), 'url' );
	apx_field( $post->ID, '_apx_reference_timestamp', __( 'Reference timestamp', 'apexik-story-engine' ), 'text', __( 'For example 01:22:14 or Lap 48.', 'apexik-story-engine' ) );
	apx_field( $post->ID, '_apx_related_products', __( 'Related product IDs', 'apexik-story-engine' ), 'text', __( 'Comma-separated WooCommerce product IDs.', 'apexik-story-engine' ) );
	apx_field( $post->ID, '_apx_rights_status', __( 'Editorial and rights status', 'apexik-story-engine' ), 'select' );
}

function apx_render_product_meta_box( $post ) {
	wp_nonce_field( 'apx_save_story_meta', 'apx_story_nonce' );
	apx_field( $post->ID, '_apx_story_summary', __( 'Design story', 'apexik-story-engine' ), 'textarea' );
	apx_field( $post->ID, '_apx_related_moments', __( 'Related Race Moment IDs', 'apexik-story-engine' ), 'text', __( 'Comma-separated approved Race Moment IDs. The product page links back to the first published moment.', 'apexik-story-engine' ) );
	apx_field( $post->ID, '_apx_design_reference', __( 'Approved design/source reference', 'apexik-story-engine' ) );
	apx_field( $post->ID, '_apx_production_notes', __( 'Production notes', 'apexik-story-engine' ), 'textarea' );
	apx_field( $post->ID, '_apx_care_notes', __( 'Care notes', 'apexik-story-engine' ), 'textarea' );
	apx_field( $post->ID, '_apx_provider', __( 'Fulfilment provider', 'apexik-story-engine' ), 'text', __( 'Informational only. Printful remains the fulfilment source.', 'apexik-story-engine' ) );
}

function apx_save_story_meta( $post_id ) {
	if ( ! isset( $_POST['apx_story_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['apx_story_nonce'] ) ), 'apx_save_story_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$keys = array(
		'_apx_event_date', '_apx_race_round', '_apx_radio_quote', '_apx_source_title', '_apx_source_url', '_apx_reference_timestamp', '_apx_related_products', '_apx_rights_status',
		'_apx_story_summary', '_apx_related_moments', '_apx_design_reference', '_apx_production_notes', '_apx_care_notes', '_apx_provider',
	);
	foreach ( $keys as $key ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$value = wp_unslash( $_POST[ $key ] );
		$value = '_apx_source_url' === $key ? esc_url_raw( $value ) : sanitize_textarea_field( $value );
		update_post_meta( $post_id, $key, $value );
	}
}
add_action( 'save_post', 'apx_save_story_meta' );
