<?php
/**
 * Plugin Name: APEXIK Story Engine
 * Description: Race Moments, shared editorial taxonomies and safe placeholder content for APEXIK commerce.
 * Version: 1.2.1
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Text Domain: apexik-story-engine
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'APX_ENGINE_VERSION', '1.2.1' );
define( 'APX_ENGINE_DIR', plugin_dir_path( __FILE__ ) );

require_once APX_ENGINE_DIR . 'inc/content-model.php';
require_once APX_ENGINE_DIR . 'inc/meta-boxes.php';
require_once APX_ENGINE_DIR . 'inc/admin-setup.php';
require_once APX_ENGINE_DIR . 'inc/integrations.php';
require_once APX_ENGINE_DIR . 'inc/management-portal.php';
require_once APX_ENGINE_DIR . 'inc/operations-modules.php';

register_activation_hook( __FILE__, 'apx_engine_activate' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

function apx_engine_activate() {
	apx_register_content_model();
	apx_register_management_portal_route();
	flush_rewrite_rules();
}
