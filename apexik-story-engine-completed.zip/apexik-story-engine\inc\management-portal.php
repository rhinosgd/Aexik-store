<?php
/**
 * Secure front-end operations portal for store staff.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_register_management_portal_route() {
	add_rewrite_rule( '^apexik-control/?$', 'index.php?apx_control=1', 'top' );
}
add_action( 'init', 'apx_register_management_portal_route' );

function apx_management_portal_query_vars( $vars ) {
	$vars[] = 'apx_control';
	return $vars;
}
add_filter( 'query_vars', 'apx_management_portal_query_vars' );

function apx_management_portal_access() {
	return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
}

function apx_management_portal_url( $view = 'dashboard', $args = array() ) {
	return add_query_arg( array_merge( array( 'view' => sanitize_key( $view ) ), $args ), home_url( '/apexik-control/' ) );
}

function apx_portal_guard( $action ) {
	if ( ! is_user_logged_in() || ! apx_management_portal_access() ) {
		wp_die( esc_html__( 'You do not have permission to manage this store.', 'apexik-story-engine' ), esc_html__( 'Access denied', 'apexik-story-engine' ), array( 'response' => 403 ) );
	}
	check_admin_referer( $action );
}

function apx_portal_redirect( $view, $notice ) {
	wp_safe_redirect( apx_management_portal_url( $view, array( 'notice' => sanitize_key( $notice ) ) ) );
	exit;
}

function apx_validate_product_media( $url = '' ) {
	if ( $url ) {
		if ( ! wp_http_validate_url( $url ) || 0 !== strpos( strtolower( $url ), 'https://' ) ) {
			return new WP_Error( 'invalid-product-url', __( 'Product image URL must be a valid HTTPS URL.', 'apexik-story-engine' ) );
		}
		return true;
	}
	if ( empty( $_FILES['product_image']['name'] ) ) {
		return true;
	}
	$file = $_FILES['product_image'];
	if ( ! empty( $file['error'] ) || (int) $file['size'] > 10 * MB_IN_BYTES ) {
		return new WP_Error( 'invalid-product-file', __( 'Product image must be smaller than 10MB.', 'apexik-story-engine' ) );
	}
	$allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
	$mime = wp_get_image_mime( $file['tmp_name'] );
	if ( ! in_array( $mime, $allowed, true ) ) {
		return new WP_Error( 'invalid-product-type', __( 'Product image must be JPG, PNG or WebP.', 'apexik-story-engine' ) );
	}
	$size = @getimagesize( $file['tmp_name'] );
	if ( ! $size || 1600 !== (int) $size[0] || 1600 !== (int) $size[1] ) {
		return new WP_Error( 'invalid-product-dimensions', __( 'Product image must be exactly 1600 × 1600 pixels.', 'apexik-story-engine' ) );
	}
	return true;
}

function apx_validate_uploaded_dimensions( $field, $width, $height ) {
	if ( empty( $_FILES[ $field ]['name'] ) ) {
		return true;
	}
	$file = $_FILES[ $field ];
	if ( ! empty( $file['error'] ) || (int) $file['size'] > 10 * MB_IN_BYTES ) {
		return new WP_Error( 'invalid-content-file', __( 'Content image must be smaller than 10MB.', 'apexik-story-engine' ) );
	}
	$mime = wp_get_image_mime( $file['tmp_name'] );
	if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
		return new WP_Error( 'invalid-content-type', __( 'Content image must be JPG, PNG or WebP.', 'apexik-story-engine' ) );
	}
	$size = @getimagesize( $file['tmp_name'] );
	if ( ! $size || (int) $size[0] !== $width || (int) $size[1] !== $height ) {
		return new WP_Error( 'invalid-content-dimensions', sprintf( __( 'Content image must be exactly %1$d × %2$d pixels.', 'apexik-story-engine' ), $width, $height ) );
	}
	return true;
}

function apx_portal_save_product() {
	apx_portal_guard( 'apx_portal_save_product' );
	if ( ! class_exists( 'WC_Product_Variable' ) ) {
		apx_portal_redirect( 'products', 'woocommerce-required' );
	}
	$title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
	if ( '' === $title ) {
		apx_portal_redirect( 'products', 'title-required' );
	}
	$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
	if ( $product_id && ! wc_get_product( $product_id ) ) {
		apx_portal_redirect( 'products', 'not-found' );
	}
	if ( $product_id ) {
		wp_set_object_terms( $product_id, 'variable', 'product_type' );
		$product = new WC_Product_Variable( $product_id );
	} else {
		$product = new WC_Product_Variable();
	}
	$price = isset( $_POST['price'] ) ? wc_format_decimal( wp_unslash( $_POST['price'] ) ) : '';
	if ( '' === $price ) {
		apx_portal_redirect( 'products', 'price-required' );
	}
	$style = isset( $_POST['style'] ) ? sanitize_text_field( wp_unslash( $_POST['style'] ) ) : 'Style A';
	$size  = isset( $_POST['size'] ) ? sanitize_text_field( wp_unslash( $_POST['size'] ) ) : '600 × 300 mm';
	$styles = isset( $_POST['style_values'] ) ? array_filter( array_map( 'sanitize_text_field', explode( ',', wp_unslash( $_POST['style_values'] ) ) ) ) : array( $style );
	$sizes  = isset( $_POST['size_values'] ) ? array_filter( array_map( 'sanitize_text_field', explode( ',', wp_unslash( $_POST['size_values'] ) ) ) ) : array( $size );
	$styles = array_values( array_unique( $styles ?: array( $style ) ) );
	$sizes  = array_values( array_unique( $sizes ?: array( $size ) ) );
	$status = isset( $_POST['status'] ) && 'publish' === sanitize_key( wp_unslash( $_POST['status'] ) ) ? 'publish' : 'draft';
	$product->set_name( $title );
	$product->set_status( $status );
	$product->set_description( isset( $_POST['description'] ) ? wp_kses_post( wp_unslash( $_POST['description'] ) ) : '' );
	$product->set_short_description( isset( $_POST['summary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['summary'] ) ) : '' );
	$product->set_slug( sanitize_title( isset( $_POST['slug'] ) ? wp_unslash( $_POST['slug'] ) : $title ) );
	$product->set_category_ids( isset( $_POST['category_ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['category_ids'] ) ) : array() );
	$attributes = array();
	foreach ( array( 'Style' => $styles, 'Size' => $sizes ) as $name => $options ) {
		$attribute = new WC_Product_Attribute();
		$attribute->set_name( $name );
		$attribute->set_options( $options );
		$attribute->set_visible( true );
		$attribute->set_variation( true );
		$attributes[] = $attribute;
	}
	$product->set_attributes( $attributes );
	$product_id = $product->save();
	update_post_meta( $product_id, '_apx_design_reference', sanitize_textarea_field( isset( $_POST['design_reference'] ) ? wp_unslash( $_POST['design_reference'] ) : '' ) );
	update_post_meta( $product_id, '_apx_seo_title', sanitize_text_field( isset( $_POST['seo_title'] ) ? wp_unslash( $_POST['seo_title'] ) : '' ) );
	update_post_meta( $product_id, '_apx_meta_description', sanitize_textarea_field( isset( $_POST['meta_description'] ) ? wp_unslash( $_POST['meta_description'] ) : '' ) );

	$compare_price = isset( $_POST['compare_price'] ) ? wc_format_decimal( wp_unslash( $_POST['compare_price'] ) ) : '';
	$children = $product->get_children();
	$variation_index = 0;
	foreach ( $styles as $style_value ) {
		foreach ( $sizes as $size_value ) {
			$variation_id = isset( $children[ $variation_index ] ) ? $children[ $variation_index ] : 0;
			$variation = $variation_id ? new WC_Product_Variation( $variation_id ) : new WC_Product_Variation();
			$variation->set_parent_id( $product_id );
			$variation->set_status( 'publish' );
			$variation->set_regular_price( $compare_price && (float) $compare_price > (float) $price ? $compare_price : $price );
			$variation->set_sale_price( $compare_price && (float) $compare_price > (float) $price ? $price : '' );
			$sku = sanitize_text_field( isset( $_POST['sku'] ) ? wp_unslash( $_POST['sku'] ) : '' );
			$variation->set_sku( $sku ? $sku . '-' . sanitize_title( $style_value ) . '-' . sanitize_title( $size_value ) : '' );
			$stock = isset( $_POST['stock'] ) ? max( 0, absint( $_POST['stock'] ) ) : 0;
			$variation->set_manage_stock( true );
			$variation->set_stock_quantity( $stock );
			$variation->set_stock_status( $stock > 0 ? 'instock' : 'outofstock' );
			$variation->set_attributes( array( 'style' => sanitize_title( $style_value ), 'size' => sanitize_title( $size_value ) ) );
			$variation->save();
			$variation_index++;
		}
	}

	if ( ! empty( $_FILES['product_image']['name'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_handle_upload( 'product_image', $product_id );
		if ( ! is_wp_error( $attachment_id ) ) {
			set_post_thumbnail( $product_id, $attachment_id );
		}
	}
	$image_url = isset( $_POST['product_image_url'] ) ? esc_url_raw( wp_unslash( $_POST['product_image_url'] ) ) : '';
	$media_check = apx_validate_product_media( $image_url );
	if ( is_wp_error( $media_check ) ) {
		apx_portal_redirect( 'products', 'invalid-product-media' );
	}
	if ( $image_url ) {
		update_post_meta( $product_id, '_apx_external_product_image', $image_url );
	}
	apx_portal_redirect( 'products', 'product-saved' );
}
add_action( 'admin_post_apx_portal_save_product', 'apx_portal_save_product' );

function apx_portal_save_article() {
	apx_portal_guard( 'apx_portal_save_article' );
	if ( is_wp_error( apx_validate_uploaded_dimensions( 'article_image', 1600, 900 ) ) ) {
		apx_portal_redirect( 'articles', 'invalid-article-media' );
	}
	$title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
	if ( '' === $title ) {
		apx_portal_redirect( 'articles', 'title-required' );
	}
	$post_id = isset( $_POST['article_id'] ) ? absint( $_POST['article_id'] ) : 0;
	$data = array(
		'post_type'    => 'apexik_moment',
		'post_title'   => $title,
		'post_excerpt' => isset( $_POST['excerpt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['excerpt'] ) ) : '',
		'post_content' => isset( $_POST['content'] ) ? wp_kses_post( wp_unslash( $_POST['content'] ) ) : '',
		'post_status'  => isset( $_POST['status'] ) && 'publish' === sanitize_key( wp_unslash( $_POST['status'] ) ) ? 'publish' : 'draft',
	);
	if ( $post_id && 'apexik_moment' === get_post_type( $post_id ) ) {
		$data['ID'] = $post_id;
	}
	$post_id = wp_insert_post( wp_slash( $data ) );
	if ( is_wp_error( $post_id ) ) {
		apx_portal_redirect( 'articles', 'save-failed' );
	}
	update_post_meta( $post_id, '_apx_source_title', sanitize_text_field( isset( $_POST['source_title'] ) ? wp_unslash( $_POST['source_title'] ) : '' ) );
	update_post_meta( $post_id, '_apx_source_url', esc_url_raw( isset( $_POST['source_url'] ) ? wp_unslash( $_POST['source_url'] ) : '' ) );
	if ( ! empty( $_FILES['article_image']['name'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_handle_upload( 'article_image', $post_id );
		if ( ! is_wp_error( $attachment_id ) ) {
			set_post_thumbnail( $post_id, $attachment_id );
		}
	}
	apx_portal_redirect( 'articles', 'article-saved' );
}
add_action( 'admin_post_apx_portal_save_article', 'apx_portal_save_article' );

function apx_portal_update_order() {
	apx_portal_guard( 'apx_portal_update_order' );
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0 ) : false;
	$status = isset( $_POST['order_status'] ) ? sanitize_key( wp_unslash( $_POST['order_status'] ) ) : '';
	$allowed = function_exists( 'wc_get_order_statuses' ) ? array_map( static function( $key ) { return str_replace( 'wc-', '', $key ); }, array_keys( wc_get_order_statuses() ) ) : array();
	if ( $order && in_array( $status, $allowed, true ) ) {
		$order->update_status( $status, __( 'Status updated from APEXIK Control.', 'apexik-story-engine' ), true );
		apx_portal_redirect( 'orders', 'order-updated' );
	}
	apx_portal_redirect( 'orders', 'save-failed' );
}
add_action( 'admin_post_apx_portal_update_order', 'apx_portal_update_order' );

function apx_portal_export_orders() {
	if ( ! is_user_logged_in() || ! apx_management_portal_access() ) {
		wp_die( esc_html__( 'You do not have permission to export orders.', 'apexik-story-engine' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'apx_portal_export_orders' );
	if ( ! function_exists( 'wc_get_orders' ) ) {
		wp_die( esc_html__( 'WooCommerce must be active.', 'apexik-story-engine' ), '', array( 'response' => 500 ) );
	}
	$orders = wc_get_orders( array( 'limit' => -1, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects' ) );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=apexik-orders-' . gmdate( 'Y-m-d' ) . '.csv' );
	$output = fopen( 'php://output', 'w' );
	fputcsv( $output, array( 'Order ID', 'Date', 'Customer', 'Country', 'SKU', 'Product', 'Variant', 'Qty', 'Amount', 'Payment', 'Status', 'Tracking' ) );
	foreach ( $orders as $order ) {
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			$variation = $product && $product->is_type( 'variation' ) ? wc_get_formatted_variation( $product, true ) : '';
			fputcsv( $output, array( $order->get_order_number(), $order->get_date_created() ? $order->get_date_created()->date( 'c' ) : '', $order->get_formatted_billing_full_name(), $order->get_billing_country(), $product ? $product->get_sku() : '', $item->get_name(), $variation, $item->get_quantity(), $item->get_total(), $order->get_payment_method_title(), $order->get_status(), $order->get_meta( '_tracking_number' ) ) );
		}
	}
	fclose( $output );
	exit;
}
add_action( 'admin_post_apx_portal_export_orders', 'apx_portal_export_orders' );

function apx_capture_inquiry() {
	check_admin_referer( 'apx_submit_inquiry' );
	if ( ! empty( $_POST['company'] ) ) {
		wp_safe_redirect( home_url( '/#contact' ) );
		exit;
	}
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	if ( ! is_email( $email ) || '' === $message ) {
		wp_safe_redirect( add_query_arg( 'contact', 'invalid', home_url( '/' ) ) . '#contact' );
		exit;
	}
	$rate_key = 'apx_inquiry_' . md5( $email . '|' . ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ) );
	if ( get_transient( $rate_key ) ) {
		wp_safe_redirect( add_query_arg( 'contact', 'wait', home_url( '/' ) ) . '#contact' );
		exit;
	}
	set_transient( $rate_key, 1, MINUTE_IN_SECONDS );
	$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$inquiry_id = wp_insert_post( array( 'post_type' => 'apexik_inquiry', 'post_status' => 'private', 'post_title' => sprintf( 'Inquiry from %s', $name ?: $email ), 'post_content' => $message ) );
	if ( ! is_wp_error( $inquiry_id ) ) {
		update_post_meta( $inquiry_id, '_apx_inquiry_name', $name );
		update_post_meta( $inquiry_id, '_apx_inquiry_email', $email );
		update_post_meta( $inquiry_id, '_apx_inquiry_phone', sanitize_text_field( isset( $_POST['whatsapp'] ) ? wp_unslash( $_POST['whatsapp'] ) : '' ) );
		update_post_meta( $inquiry_id, '_apx_inquiry_status', 'new' );
	}
	wp_safe_redirect( add_query_arg( 'contact', 'sent', home_url( '/' ) ) . '#contact' );
	exit;
}
add_action( 'admin_post_apx_submit_inquiry', 'apx_capture_inquiry' );
add_action( 'admin_post_nopriv_apx_submit_inquiry', 'apx_capture_inquiry' );

function apx_portal_reply_inquiry() {
	apx_portal_guard( 'apx_portal_reply_inquiry' );
	$inquiry_id = isset( $_POST['inquiry_id'] ) ? absint( $_POST['inquiry_id'] ) : 0;
	$reply = isset( $_POST['reply'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reply'] ) ) : '';
	$email = sanitize_email( get_post_meta( $inquiry_id, '_apx_inquiry_email', true ) );
	if ( 'apexik_inquiry' !== get_post_type( $inquiry_id ) || ! is_email( $email ) || '' === $reply ) {
		apx_portal_redirect( 'messages', 'reply-invalid' );
	}
	$sent = wp_mail( $email, __( 'Reply from APEXIK', 'apexik-story-engine' ), $reply );
	if ( $sent ) {
		update_post_meta( $inquiry_id, '_apx_inquiry_status', 'replied' );
		update_post_meta( $inquiry_id, '_apx_inquiry_reply', $reply );
		update_post_meta( $inquiry_id, '_apx_inquiry_replied_at', current_time( 'mysql' ) );
		apx_portal_redirect( 'messages', 'reply-sent' );
	}
	apx_portal_redirect( 'messages', 'mail-failed' );
}
add_action( 'admin_post_apx_portal_reply_inquiry', 'apx_portal_reply_inquiry' );

function apx_portal_notice() {
	$notices = array(
		'product-saved' => array( 'success', __( 'Product saved.', 'apexik-story-engine' ) ),
		'invalid-product-media' => array( 'error', __( 'Product image rejected. Use a 1600 × 1600 JPG, PNG or WebP, or a valid HTTPS image URL.', 'apexik-story-engine' ) ),
		'invalid-article-media' => array( 'error', __( 'Race Moment image rejected. Use a 1600 × 900 JPG, PNG or WebP.', 'apexik-story-engine' ) ),
		'article-saved' => array( 'success', __( 'Race Moment saved.', 'apexik-story-engine' ) ),
		'order-updated' => array( 'success', __( 'Order status updated.', 'apexik-story-engine' ) ),
		'settings-saved' => array( 'success', __( 'Settings saved.', 'apexik-story-engine' ) ),
		'category-saved' => array( 'success', __( 'Category saved.', 'apexik-story-engine' ) ),
		'inventory-saved' => array( 'success', __( 'Inventory saved.', 'apexik-story-engine' ) ),
		'content-saved' => array( 'success', __( 'Content saved.', 'apexik-story-engine' ) ),
		'media-saved' => array( 'success', __( 'External image saved.', 'apexik-story-engine' ) ),
		'reply-sent' => array( 'success', __( 'Reply sent and inquiry marked as replied.', 'apexik-story-engine' ) ),
		'title-required' => array( 'error', __( 'A title is required.', 'apexik-story-engine' ) ),
		'price-required' => array( 'error', __( 'A product price is required.', 'apexik-story-engine' ) ),
		'woocommerce-required' => array( 'error', __( 'WooCommerce must be active.', 'apexik-story-engine' ) ),
		'mail-failed' => array( 'error', __( 'The message was not sent. Check the production mail connection and try again.', 'apexik-story-engine' ) ),
		'reply-invalid' => array( 'error', __( 'The inquiry or reply is invalid.', 'apexik-story-engine' ) ),
		'save-failed' => array( 'error', __( 'The change could not be saved. Try again.', 'apexik-story-engine' ) ),
		'not-found' => array( 'error', __( 'The requested record was not found.', 'apexik-story-engine' ) ),
	);
	$key = isset( $_GET['notice'] ) ? sanitize_key( wp_unslash( $_GET['notice'] ) ) : '';
	return isset( $notices[ $key ] ) ? $notices[ $key ] : null;
}

function apx_render_management_portal() {
	if ( ! get_query_var( 'apx_control' ) ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		auth_redirect();
	}
	if ( ! apx_management_portal_access() ) {
		wp_die( esc_html__( 'You do not have permission to manage this store.', 'apexik-story-engine' ), esc_html__( 'Access denied', 'apexik-story-engine' ), array( 'response' => 403 ) );
	}

	$views = array(
		'dashboard'      => 'Dashboard',
		'products'       => 'Products',
		'categories'     => 'Categories',
		'variants'       => 'Variants / SKU',
		'orders'         => 'Orders',
		'customers'      => 'Customers',
		'inventory'      => 'Inventory',
		'articles'       => 'Race Moment',
		'messages'       => 'Inquiries',
		'pages'          => 'Pages',
		'homepage'       => 'Homepage',
		'banners'        => 'Banners',
		'media'          => 'Media Library',
		'coupons'        => 'Coupons',
		'seo'            => 'SEO',
		'email'          => 'Email',
		'settings'       => 'Settings',
		'administrators' => 'Administrators',
	);
	$view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'dashboard';
	$view = isset( $views[ $view ] ) ? $view : 'dashboard';
	$product_counts = post_type_exists( 'product' ) ? wp_count_posts( 'product' ) : null;
	$moment_counts = wp_count_posts( 'apexik_moment' );
	$inquiry_counts = wp_count_posts( 'apexik_inquiry' );
	$recent_orders = function_exists( 'wc_get_orders' ) ? wc_get_orders( array( 'limit' => 20, 'orderby' => 'date', 'order' => 'DESC' ) ) : array();
	$customer_orders = function_exists( 'wc_get_orders' ) ? wc_get_orders( array( 'limit' => 100, 'orderby' => 'date', 'order' => 'DESC' ) ) : array();
	$products = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC' ) );
	$articles = get_posts( array( 'post_type' => 'apexik_moment', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC' ) );
	$inquiries = get_posts( array( 'post_type' => 'apexik_inquiry', 'post_status' => 'private', 'posts_per_page' => 30, 'orderby' => 'date', 'order' => 'DESC' ) );
	$categories = taxonomy_exists( 'product_cat' ) ? get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) ) : array();
	$edit_product = isset( $_GET['product_id'] ) && function_exists( 'wc_get_product' ) ? wc_get_product( absint( $_GET['product_id'] ) ) : null;
	$edit_article = isset( $_GET['article_id'] ) ? get_post( absint( $_GET['article_id'] ) ) : null;
	if ( $edit_article && 'apexik_moment' !== $edit_article->post_type ) {
		$edit_article = null;
	}
	$customers = array();
	foreach ( $customer_orders as $order ) {
		$email = sanitize_email( $order->get_billing_email() );
		if ( ! $email ) {
			continue;
		}
		if ( ! isset( $customers[ $email ] ) ) {
			$customers[ $email ] = array( 'name' => $order->get_formatted_billing_full_name(), 'email' => $email, 'phone' => $order->get_billing_phone(), 'country' => $order->get_billing_country(), 'orders' => 0, 'spent' => 0 );
		}
		$customers[ $email ]['orders']++;
		$customers[ $email ]['spent'] += (float) $order->get_total();
	}
	$asset_base = plugins_url( 'assets/', APX_ENGINE_DIR . 'apexik-story-engine.php' );
	$notice = apx_portal_notice();
	status_header( 200 );
	nocache_headers();
	?><!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?php echo esc_html( $views[ $view ] . ' — APEXIK Control' ); ?></title><link rel="stylesheet" href="<?php echo esc_url( $asset_base . 'management-portal.css?ver=' . APX_ENGINE_VERSION ); ?>"><link rel="stylesheet" href="<?php echo esc_url( $asset_base . 'management-portal-extra.css?ver=' . APX_ENGINE_VERSION ); ?>"><?php wp_head(); ?></head>
	<body class="apx-control-body"><a class="apx-control-skip" href="#apx-control-main">跳至内容</a><button class="apx-control-menu" type="button" data-control-menu aria-controls="apx-control-nav" aria-expanded="false">菜单</button><button class="apx-control-collapse" type="button" data-control-collapse aria-controls="apx-control-nav" aria-expanded="true" aria-label="收起侧栏" title="收起侧栏"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 6-6 6 6 6"/></svg></button><div class="apx-control-shell">
	<aside class="apx-control-nav" id="apx-control-nav" data-control-nav><a class="apx-control-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">APE<b>X</b><span>IK</span></a><p>STORE OPERATIONS</p><nav><?php foreach ( $views as $slug => $label ) : ?><a class="<?php echo $view === $slug ? 'is-active' : ''; ?>" href="<?php echo esc_url( apx_management_portal_url( $slug ) ); ?>"><span><?php echo esc_html( str_pad( (string) ( array_search( $slug, array_keys( $views ), true ) + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><?php echo esc_html( $label ); ?></a><?php endforeach; ?></nav><div class="apx-control-nav__foot"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">查看店铺</a><a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">退出登录</a></div></aside>
	<main class="apx-control-main" id="apx-control-main"><header class="apx-control-header"><div><h1><?php echo esc_html( $views[ $view ] ); ?></h1><p><?php echo esc_html( wp_get_current_user()->display_name ); ?> · 安全管理会话</p></div><time datetime="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>"><?php echo esc_html( wp_date( 'Y.m.d' ) ); ?></time></header>
	<?php if ( $notice ) : ?><div class="apx-control-notice apx-control-notice--<?php echo esc_attr( $notice[0] ); ?>" role="status"><?php echo esc_html( $notice[1] ); ?></div><?php endif; ?>
	<?php if ( 'dashboard' === $view ) : ?>
		<section class="apx-control-metrics" aria-label="Store summary"><a href="<?php echo esc_url( apx_management_portal_url( 'orders' ) ); ?>"><span>订单</span><strong><?php echo esc_html( count( $recent_orders ) ); ?></strong><small>最近记录</small></a><a href="<?php echo esc_url( apx_management_portal_url( 'products' ) ); ?>"><span>已发布产品</span><strong><?php echo esc_html( $product_counts ? (int) $product_counts->publish : 0 ); ?></strong><small>进入产品上新</small></a><a href="<?php echo esc_url( apx_management_portal_url( 'messages' ) ); ?>"><span>待处理咨询</span><strong><?php echo esc_html( $inquiry_counts ? (int) $inquiry_counts->private : 0 ); ?></strong><small>进入咨询回复</small></a><a href="<?php echo esc_url( apx_management_portal_url( 'articles' ) ); ?>"><span>已发布文章</span><strong><?php echo esc_html( (int) $moment_counts->publish ); ?></strong><small>更新 Race Moment</small></a></section>
		<section class="apx-control-panel apx-control-panel--split"><div><h2>今日工作台</h2><p>订单、产品、咨询和 Race Moment 全部在此门户维护。WooCommerce 仍负责订单、税费和客户数据，管理端只提供更聚焦的操作界面。</p></div><div class="apx-control-quick"><a href="<?php echo esc_url( apx_management_portal_url( 'products' ) ); ?>">新建产品</a><a href="<?php echo esc_url( apx_management_portal_url( 'messages' ) ); ?>">处理咨询</a><a href="<?php echo esc_url( apx_management_portal_url( 'articles' ) ); ?>">发布文章</a></div></section>
	<?php elseif ( 'orders' === $view ) : ?>
		<section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2>最近订单</h2><p>直接查看买家、金额并更新履约状态。</p></div><span><?php echo esc_html( count( $recent_orders ) ); ?> 条</span></div><div class="apx-control-table apx-control-table--orders"><div class="apx-control-row apx-control-row--head"><span>订单</span><span>客户</span><span>日期</span><span>金额</span><span>状态</span></div><?php if ( $recent_orders ) : foreach ( $recent_orders as $order ) : ?><div class="apx-control-row"><strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong><span><?php echo esc_html( $order->get_formatted_billing_full_name() ?: 'Guest' ); ?><small><?php echo esc_html( $order->get_billing_email() ); ?></small></span><time><?php echo esc_html( $order->get_date_created() ? $order->get_date_created()->date_i18n( 'Y.m.d' ) : '' ); ?></time><span><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></span><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="apx_portal_update_order"><input type="hidden" name="order_id" value="<?php echo esc_attr( $order->get_id() ); ?>"><?php wp_nonce_field( 'apx_portal_update_order' ); ?><select name="order_status" aria-label="订单 <?php echo esc_attr( $order->get_order_number() ); ?> 状态"><?php foreach ( wc_get_order_statuses() as $status_key => $status_label ) : $status_slug = str_replace( 'wc-', '', $status_key ); ?><option value="<?php echo esc_attr( $status_slug ); ?>" <?php selected( $order->get_status(), $status_slug ); ?>><?php echo esc_html( $status_label ); ?></option><?php endforeach; ?></select><button type="submit">保存</button></form></div><?php endforeach; else : ?><div class="apx-control-empty"><h3>暂无订单</h3><p>首笔订单完成后会显示在这里。</p></div><?php endif; ?></div></section>
	<?php elseif ( 'products' === $view ) : ?>
		<div class="apx-control-workspace"><section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2><?php echo $edit_product ? '编辑产品' : '新建产品'; ?></h2><p>新产品默认保存为草稿，确认后再发布并连接 Printful。</p></div></div><form class="apx-control-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="apx_portal_save_product"><input type="hidden" name="product_id" value="<?php echo esc_attr( $edit_product ? $edit_product->get_id() : 0 ); ?>"><?php wp_nonce_field( 'apx_portal_save_product' ); ?><label class="apx-field apx-field--wide"><span>产品名称 *</span><input name="title" maxlength="160" required value="<?php echo esc_attr( $edit_product ? $edit_product->get_name() : '' ); ?>"></label><label class="apx-field"><span>售价</span><input name="price" type="number" min="0" step="0.01" inputmode="decimal" value="<?php echo esc_attr( $edit_product ? $edit_product->get_price() : '' ); ?>"></label><label class="apx-field"><span>状态</span><select name="status"><option value="draft" <?php selected( $edit_product ? $edit_product->get_status() : 'draft', 'draft' ); ?>>草稿</option><option value="publish" <?php selected( $edit_product ? $edit_product->get_status() : '', 'publish' ); ?>>发布</option></select></label><label class="apx-field"><span>Style</span><input name="style" value="Style A" maxlength="80"></label><label class="apx-field"><span>Size</span><input name="size" value="600 × 300 mm" maxlength="80"></label><fieldset class="apx-field apx-field--wide"><legend>产品分类</legend><div class="apx-check-grid"><?php if ( ! is_wp_error( $categories ) ) : foreach ( $categories as $category ) : ?><label><input type="checkbox" name="category_ids[]" value="<?php echo esc_attr( $category->term_id ); ?>" <?php checked( $edit_product && has_term( $category->term_id, 'product_cat', $edit_product->get_id() ) ); ?>><?php echo esc_html( $category->name ); ?></label><?php endforeach; endif; ?></div></fieldset><label class="apx-field apx-field--wide"><span>产品摘要</span><textarea name="summary" rows="3" maxlength="500"><?php echo esc_textarea( $edit_product ? $edit_product->get_short_description() : '' ); ?></textarea></label><label class="apx-field apx-field--wide"><span>产品详情</span><textarea name="description" rows="7"><?php echo esc_textarea( $edit_product ? $edit_product->get_description() : '' ); ?></textarea></label><label class="apx-field"><span>主图</span><input type="file" name="product_image" accept="image/jpeg,image/png,image/webp"></label><label class="apx-field"><span>设计来源备注</span><textarea name="design_reference" rows="3"><?php echo esc_textarea( $edit_product ? $edit_product->get_meta( '_apx_design_reference' ) : '' ); ?></textarea></label><div class="apx-form-actions"><button type="submit"><?php echo $edit_product ? '保存产品' : '创建产品'; ?></button><span>保存后仍由 WooCommerce 管理库存、税费和订单。</span></div></form></section><aside class="apx-control-panel apx-control-list"><h2>最近产品</h2><?php if ( $products ) : foreach ( $products as $item ) : $item_product = wc_get_product( $item->ID ); ?><a href="<?php echo esc_url( apx_management_portal_url( 'products', array( 'product_id' => $item->ID ) ) ); ?>"><span><?php echo esc_html( get_the_title( $item ) ); ?><small><?php echo esc_html( ucfirst( $item->post_status ) ); ?></small></span><strong><?php echo $item_product ? wp_kses_post( $item_product->get_price_html() ) : ''; ?></strong></a><?php endforeach; else : ?><p>暂无产品。</p><?php endif; ?></aside></div>
	<?php elseif ( 'messages' === $view ) : ?>
		<section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2>咨询收件箱</h2><p>回复会发送至客户提交的邮箱，并记录回复状态。</p></div><span><?php echo esc_html( count( $inquiries ) ); ?> 条</span></div><div class="apx-inquiries"><?php if ( $inquiries ) : foreach ( $inquiries as $inquiry ) : $inquiry_status = get_post_meta( $inquiry->ID, '_apx_inquiry_status', true ); ?><article><header><div><h3><?php echo esc_html( get_post_meta( $inquiry->ID, '_apx_inquiry_name', true ) ?: '未署名客户' ); ?></h3><a href="mailto:<?php echo esc_attr( get_post_meta( $inquiry->ID, '_apx_inquiry_email', true ) ); ?>"><?php echo esc_html( get_post_meta( $inquiry->ID, '_apx_inquiry_email', true ) ); ?></a></div><span class="apx-status apx-status--<?php echo esc_attr( $inquiry_status ?: 'new' ); ?>"><?php echo 'replied' === $inquiry_status ? '已回复' : '待回复'; ?></span></header><p><?php echo nl2br( esc_html( $inquiry->post_content ) ); ?></p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="apx_portal_reply_inquiry"><input type="hidden" name="inquiry_id" value="<?php echo esc_attr( $inquiry->ID ); ?>"><?php wp_nonce_field( 'apx_portal_reply_inquiry' ); ?><label class="apx-field"><span>回复内容</span><textarea name="reply" rows="4" required><?php echo esc_textarea( get_post_meta( $inquiry->ID, '_apx_inquiry_reply', true ) ); ?></textarea></label><button type="submit">发送回复</button></form></article><?php endforeach; else : ?><div class="apx-control-empty"><h3>暂无咨询</h3><p>客户提交联系表单后，消息会显示在这里。</p></div><?php endif; ?></div></section>
	<?php elseif ( 'articles' === $view ) : ?>
		<div class="apx-control-workspace"><section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2><?php echo $edit_article ? '编辑 Race Moment' : '新建 Race Moment'; ?></h2><p>编辑比赛故事、来源和发布状态。</p></div></div><form class="apx-control-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="apx_portal_save_article"><input type="hidden" name="article_id" value="<?php echo esc_attr( $edit_article ? $edit_article->ID : 0 ); ?>"><?php wp_nonce_field( 'apx_portal_save_article' ); ?><label class="apx-field apx-field--wide"><span>文章标题 *</span><input name="title" maxlength="180" required value="<?php echo esc_attr( $edit_article ? $edit_article->post_title : '' ); ?>"></label><label class="apx-field"><span>状态</span><select name="status"><option value="draft" <?php selected( $edit_article ? $edit_article->post_status : 'draft', 'draft' ); ?>>草稿</option><option value="publish" <?php selected( $edit_article ? $edit_article->post_status : '', 'publish' ); ?>>发布</option></select></label><label class="apx-field"><span>封面图</span><input type="file" name="article_image" accept="image/jpeg,image/png,image/webp"></label><label class="apx-field apx-field--wide"><span>摘要</span><textarea name="excerpt" rows="3" maxlength="500"><?php echo esc_textarea( $edit_article ? $edit_article->post_excerpt : '' ); ?></textarea></label><label class="apx-field apx-field--wide"><span>正文</span><textarea name="content" rows="12"><?php echo esc_textarea( $edit_article ? $edit_article->post_content : '' ); ?></textarea></label><label class="apx-field"><span>来源标题</span><input name="source_title" value="<?php echo esc_attr( $edit_article ? get_post_meta( $edit_article->ID, '_apx_source_title', true ) : '' ); ?>"></label><label class="apx-field"><span>来源链接</span><input name="source_url" type="url" value="<?php echo esc_attr( $edit_article ? get_post_meta( $edit_article->ID, '_apx_source_url', true ) : '' ); ?>"></label><div class="apx-form-actions"><button type="submit"><?php echo $edit_article ? '保存文章' : '创建文章'; ?></button><span>正式发布前请核对赛事事实与来源。</span></div></form></section><aside class="apx-control-panel apx-control-list"><h2>最近文章</h2><?php if ( $articles ) : foreach ( $articles as $article ) : ?><a href="<?php echo esc_url( apx_management_portal_url( 'articles', array( 'article_id' => $article->ID ) ) ); ?>"><span><?php echo esc_html( get_the_title( $article ) ); ?><small><?php echo esc_html( ucfirst( $article->post_status ) ); ?> · <?php echo esc_html( get_the_date( 'Y.m.d', $article ) ); ?></small></span></a><?php endforeach; else : ?><p>暂无 Race Moment。</p><?php endif; ?></aside></div>
	<?php elseif ( in_array( $view, array( 'categories', 'variants', 'inventory', 'pages', 'homepage', 'banners', 'media', 'coupons', 'seo', 'email', 'settings', 'administrators' ), true ) ) : ?>
		<?php apx_render_operations_view( $view ); ?>
	<?php else : ?>
		<section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2>下单客户</h2><p>资料直接读取最近 WooCommerce 订单，不建立第二份客户数据库。</p></div><span><?php echo esc_html( count( $customers ) ); ?> 位</span></div><div class="apx-control-table apx-control-table--customers"><div class="apx-control-row apx-control-row--head"><span>客户</span><span>联系方式</span><span>国家</span><span>订单</span><span>消费</span></div><?php if ( $customers ) : foreach ( $customers as $customer ) : ?><div class="apx-control-row"><strong><?php echo esc_html( $customer['name'] ?: 'Guest' ); ?></strong><span><a href="mailto:<?php echo esc_attr( $customer['email'] ); ?>"><?php echo esc_html( $customer['email'] ); ?></a><small><?php echo esc_html( $customer['phone'] ); ?></small></span><span><?php echo esc_html( $customer['country'] ); ?></span><span><?php echo esc_html( $customer['orders'] ); ?></span><span><?php echo function_exists( 'wc_price' ) ? wp_kses_post( wc_price( $customer['spent'] ) ) : esc_html( $customer['spent'] ); ?></span></div><?php endforeach; else : ?><div class="apx-control-empty"><h3>暂无客户数据</h3><p>产生订单后，买家联系方式会在这里显示。</p></div><?php endif; ?></div><p class="apx-control-privacy">仅授权店铺管理员可见。导出、营销订阅和数据删除应另行遵循适用的隐私法规与客户授权。</p></section>
	<?php endif; ?>
	</main></div><script src="<?php echo esc_url( $asset_base . 'management-portal.js?ver=' . APX_ENGINE_VERSION ); ?>" defer></script><?php wp_footer(); ?></body></html><?php
	exit;
}
add_action( 'template_redirect', 'apx_render_management_portal' );
