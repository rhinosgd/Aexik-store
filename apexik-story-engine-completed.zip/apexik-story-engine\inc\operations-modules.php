<?php
/**
 * Additional APEXIK Control modules required by the production specification.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_ops_upload_image( $field, $parent_id = 0 ) {
	if ( empty( $_FILES[ $field ]['name'] ) ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$attachment_id = media_handle_upload( $field, $parent_id );
	return is_wp_error( $attachment_id ) ? 0 : (int) $attachment_id;
}

function apx_ops_https_url( $value ) {
	$url = esc_url_raw( wp_unslash( $value ) );
	return $url && wp_http_validate_url( $url ) && 0 === strpos( strtolower( $url ), 'https://' ) ? $url : '';
}

function apx_ops_save_settings() {
	apx_portal_guard( 'apx_ops_save_settings' );
	$mode = isset( $_POST['intro_mode'] ) ? sanitize_key( wp_unslash( $_POST['intro_mode'] ) ) : 'always';
	update_option( 'apx_intro_mode', in_array( $mode, array( 'always', 'first', 'off' ), true ) ? $mode : 'always' );
	update_option( 'apx_intro_duration', max( 2200, min( 8000, absint( $_POST['intro_duration'] ?? 4200 ) ) ) );
	update_option( 'woocommerce_notify_low_stock_amount', max( 0, absint( $_POST['low_stock'] ?? 5 ) ) );
	apx_portal_redirect( 'settings', 'settings-saved' );
}
add_action( 'admin_post_apx_ops_save_settings', 'apx_ops_save_settings' );

function apx_ops_save_category() {
	apx_portal_guard( 'apx_ops_save_category' );
	$name = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	if ( '' === $name ) {
		apx_portal_redirect( 'categories', 'title-required' );
	}
	$args = array(
		'slug'        => sanitize_title( wp_unslash( $_POST['slug'] ?? $name ) ),
		'description' => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
	);
	$term_id = absint( $_POST['term_id'] ?? 0 );
	$result = $term_id ? wp_update_term( $term_id, 'product_cat', array_merge( $args, array( 'name' => $name ) ) ) : wp_insert_term( $name, 'product_cat', $args );
	if ( ! is_wp_error( $result ) ) {
		$id = $term_id ?: (int) $result['term_id'];
		update_term_meta( $id, 'order', absint( $_POST['order'] ?? 0 ) );
	}
	apx_portal_redirect( 'categories', is_wp_error( $result ) ? 'save-failed' : 'category-saved' );
}
add_action( 'admin_post_apx_ops_save_category', 'apx_ops_save_category' );

function apx_ops_save_inventory() {
	apx_portal_guard( 'apx_ops_save_inventory' );
	foreach ( (array) ( $_POST['stock'] ?? array() ) as $product_id => $quantity ) {
		$product = wc_get_product( absint( $product_id ) );
		if ( ! $product ) {
			continue;
		}
		$product->set_manage_stock( true );
		$product->set_stock_quantity( max( 0, absint( $quantity ) ) );
		$product->set_stock_status( absint( $quantity ) > 0 ? 'instock' : 'outofstock' );
		$product->save();
	}
	apx_portal_redirect( 'inventory', 'inventory-saved' );
}
add_action( 'admin_post_apx_ops_save_inventory', 'apx_ops_save_inventory' );

function apx_ops_save_content() {
	apx_portal_guard( 'apx_ops_save_content' );
	$section = sanitize_key( wp_unslash( $_POST['section'] ?? 'homepage' ) );
	if ( ! in_array( $section, array( 'homepage', 'banners', 'seo', 'email' ), true ) ) {
		apx_portal_redirect( 'dashboard', 'save-failed' );
	}
	$allowed = array(
		'homepage' => array( 'hero_kicker', 'hero_title', 'hero_copy', 'hero_cta' ),
		'banners'   => array( 'banner_title', 'banner_copy', 'banner_link' ),
		'seo'       => array( 'seo_title', 'seo_description', 'seo_canonical' ),
		'email'     => array( 'email_from_name', 'email_from_address', 'email_reply_to' ),
	);
	foreach ( $allowed[ $section ] as $key ) {
		$value = wp_unslash( $_POST[ $key ] ?? '' );
		update_option( 'apx_' . $key, false !== strpos( $key, 'description' ) || false !== strpos( $key, 'copy' ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ) );
	}
	if ( in_array( $section, array( 'homepage', 'banners' ), true ) ) {
		$field = 'homepage' === $section ? 'hero_image' : 'banner_image';
		$image_id = apx_ops_upload_image( $field );
		if ( $image_id ) {
			update_option( 'apx_' . $field . '_id', $image_id );
		}
		$image_url = apx_ops_https_url( $_POST[ $field . '_url' ] ?? '' );
		if ( $image_url ) {
			update_option( 'apx_' . $field . '_url', $image_url );
		}
	}
	apx_portal_redirect( $section, 'content-saved' );
}
add_action( 'admin_post_apx_ops_save_content', 'apx_ops_save_content' );

function apx_ops_add_external_media() {
	apx_portal_guard( 'apx_ops_add_external_media' );
	$url = apx_ops_https_url( $_POST['external_media_url'] ?? '' );
	if ( $url ) {
		$items = (array) get_option( 'apx_external_media', array() );
		$items[] = array( 'url' => $url, 'label' => sanitize_text_field( wp_unslash( $_POST['external_media_label'] ?? '' ) ), 'created' => current_time( 'mysql' ) );
		update_option( 'apx_external_media', array_slice( $items, -100 ) );
	}
	apx_portal_redirect( 'media', $url ? 'media-saved' : 'save-failed' );
}
add_action( 'admin_post_apx_ops_add_external_media', 'apx_ops_add_external_media' );

function apx_ops_field( $label, $name, $value = '', $type = 'text' ) {
	if ( 'textarea' === $type ) {
		echo '<label class="apx-field apx-field--wide"><span>' . esc_html( $label ) . '</span><textarea name="' . esc_attr( $name ) . '" rows="4">' . esc_textarea( $value ) . '</textarea></label>';
		return;
	}
	echo '<label class="apx-field"><span>' . esc_html( $label ) . '</span><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"></label>';
}

function apx_render_operations_view( $view ) {
	if ( 'categories' === $view ) {
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'meta_key' => 'order', 'orderby' => 'meta_value_num' ) );
		echo '<div class="apx-control-workspace"><section class="apx-control-panel"><h2>Category</h2><form class="apx-control-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="apx_ops_save_category">';
		wp_nonce_field( 'apx_ops_save_category' );
		apx_ops_field( 'Name *', 'name' ); apx_ops_field( 'Slug', 'slug' ); apx_ops_field( 'Order', 'order', '0', 'number' ); apx_ops_field( 'Description', 'description', '', 'textarea' );
		echo '<div class="apx-form-actions"><button type="submit">Save category</button></div></form></section><aside class="apx-control-panel apx-control-list"><h2>Current order</h2>';
		foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) {
			echo '<a href="#"><span>' . esc_html( $term->name ) . '<small>' . esc_html( $term->slug ) . '</small></span><strong>' . esc_html( get_term_meta( $term->term_id, 'order', true ) ?: 0 ) . '</strong></a>';
		}
		echo '</aside></div>';
		return;
	}
	if ( 'variants' === $view || 'inventory' === $view ) {
		$products = wc_get_products( array( 'limit' => 100, 'status' => array( 'publish', 'draft' ), 'type' => array( 'variable', 'variation', 'simple' ) ) );
		echo '<section class="apx-control-panel"><div class="apx-control-panel__head"><div><h2>' . esc_html( 'variants' === $view ? 'Variants / SKU' : 'Inventory' ) . '</h2><p>WooCommerce remains the single source of truth.</p></div></div>';
		if ( 'inventory' === $view ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="apx_ops_save_inventory">'; wp_nonce_field( 'apx_ops_save_inventory' );
		}
		echo '<div class="apx-control-table"><div class="apx-control-row apx-control-row--head"><span>ID</span><span>Product / SKU</span><span>Type</span><span>Price</span><span>Stock</span></div>';
		foreach ( $products as $product ) {
			$stock = null === $product->get_stock_quantity() ? 0 : $product->get_stock_quantity();
			echo '<div class="apx-control-row"><strong>#' . esc_html( $product->get_id() ) . '</strong><span>' . esc_html( $product->get_name() ) . '<small>' . esc_html( $product->get_sku() ?: 'No SKU' ) . '</small></span><span>' . esc_html( $product->get_type() ) . '</span><span>' . wp_kses_post( $product->get_price_html() ) . '</span><span>';
			if ( 'inventory' === $view ) {
				echo '<input type="number" min="0" name="stock[' . esc_attr( $product->get_id() ) . ']" value="' . esc_attr( $stock ) . '">';
			} else {
				echo esc_html( $stock );
			}
			echo '</span></div>';
		}
		echo '</div>';
		if ( 'inventory' === $view ) {
			echo '<div class="apx-form-actions"><button type="submit">Save inventory</button></div></form>';
		}
		echo '</section>';
		return;
	}
	if ( in_array( $view, array( 'homepage', 'banners', 'seo', 'email' ), true ) ) {
		$fields = array(
			'homepage' => array( 'hero_kicker' => 'Hero kicker', 'hero_title' => 'Hero title', 'hero_copy' => 'Hero copy', 'hero_cta' => 'CTA label' ),
			'banners'   => array( 'banner_title' => 'Banner title', 'banner_copy' => 'Banner copy', 'banner_link' => 'Banner link' ),
			'seo'       => array( 'seo_title' => 'SEO title', 'seo_description' => 'Meta description', 'seo_canonical' => 'Canonical URL' ),
			'email'     => array( 'email_from_name' => 'From name', 'email_from_address' => 'From email', 'email_reply_to' => 'Reply-to email' ),
		);
		echo '<section class="apx-control-panel"><h2>' . esc_html( ucfirst( $view ) ) . '</h2><form class="apx-control-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="apx_ops_save_content"><input type="hidden" name="section" value="' . esc_attr( $view ) . '">'; wp_nonce_field( 'apx_ops_save_content' );
		foreach ( $fields[ $view ] as $name => $label ) {
			apx_ops_field( $label, $name, get_option( 'apx_' . $name, '' ), false !== strpos( $name, 'copy' ) || false !== strpos( $name, 'description' ) ? 'textarea' : 'text' );
		}
		if ( in_array( $view, array( 'homepage', 'banners' ), true ) ) {
			$image = 'homepage' === $view ? 'hero_image' : 'banner_image';
			apx_ops_field( 'Local image', $image, '', 'file' ); apx_ops_field( 'HTTPS image URL', $image . '_url', get_option( 'apx_' . $image . '_url', '' ), 'url' );
		}
		echo '<div class="apx-form-actions"><button type="submit">Save</button></div></form></section>';
		return;
	}
	if ( 'media' === $view ) {
		$external = array_reverse( (array) get_option( 'apx_external_media', array() ) );
		echo '<section class="apx-control-panel"><h2>Media Library</h2><form class="apx-control-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="apx_ops_add_external_media">'; wp_nonce_field( 'apx_ops_add_external_media' ); apx_ops_field( 'Label', 'external_media_label' ); apx_ops_field( 'HTTPS image URL', 'external_media_url', '', 'url' ); echo '<div class="apx-form-actions"><button type="submit">Add external image</button></div></form><div class="apx-media-grid">';
		foreach ( $external as $item ) {
			echo '<figure><img src="' . esc_url( $item['url'] ) . '" alt=""><figcaption>' . esc_html( $item['label'] ?: $item['url'] ) . '</figcaption></figure>';
		}
		echo '</div></section>';
		return;
	}
	if ( 'settings' === $view ) {
		echo '<section class="apx-control-panel"><h2>Settings</h2><form class="apx-control-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="apx_ops_save_settings">'; wp_nonce_field( 'apx_ops_save_settings' );
		echo '<label class="apx-field"><span>Homepage intro</span><select name="intro_mode"><option value="always" ' . selected( get_option( 'apx_intro_mode', 'always' ), 'always', false ) . '>Every visit</option><option value="first" ' . selected( get_option( 'apx_intro_mode' ), 'first', false ) . '>Once per session</option><option value="off" ' . selected( get_option( 'apx_intro_mode' ), 'off', false ) . '>Off</option></select></label>';
		apx_ops_field( 'Intro duration (ms)', 'intro_duration', get_option( 'apx_intro_duration', 4200 ), 'number' ); apx_ops_field( 'Low stock threshold', 'low_stock', get_option( 'woocommerce_notify_low_stock_amount', 5 ), 'number' );
		echo '<div class="apx-form-actions"><button type="submit">Save settings</button></div></form></section>';
		return;
	}
	if ( 'administrators' === $view ) {
		$users = get_users( array( 'role__in' => array( 'administrator', 'shop_manager' ) ) );
		echo '<section class="apx-control-panel"><h2>Administrators</h2><div class="apx-control-list">'; foreach ( $users as $user ) { echo '<a href="#"><span>' . esc_html( $user->display_name ) . '<small>' . esc_html( $user->user_email ) . '</small></span><strong>' . esc_html( implode( ', ', $user->roles ) ) . '</strong></a>'; } echo '</div></section>';
		return;
	}
	echo '<section class="apx-control-panel"><h2>' . esc_html( ucfirst( $view ) ) . '</h2><p>This module uses WooCommerce data and is being connected to the APEXIK Control workflow.</p></section>';
}
