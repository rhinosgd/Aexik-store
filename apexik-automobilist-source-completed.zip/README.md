# APEXIK Automobilist Story Commerce

全新的 WordPress + WooCommerce 结构原型。项目未修改任何旧网站文件。

## 本次交付

- `wordpress/wp-content/themes/apexik-automobilist/`：自建主题。
- `wordpress/wp-content/plugins/apexik-story-engine/`：Race Moments 内容模型、分类和占位内容工具。
- `preview/`：与主题共享 CSS/JS 的静态交互预览。
- `packages/`：可上传 WordPress 的主题、插件和完整源码 ZIP。

## 首页结构

- New Arrivals：真实产品占位图，图片进入商品详情页。
- Shop All：All / Desk Mats / Clothing / Stickers / Key Chains / Curated Finds，单行五商品。
- Race Moments：左图、右侧五条文章标题，聚焦/悬停切换对应图片，文章可持续更新。
- Paddock’s Fun & Meme：All Story / Pit Wall / Team Radio / Driver Talk / Paddock Review，单行五商品。
- Proof：赛车背景与半透明黑色遮罩。
- About、FAQ、Contact；Contact 展开姓名、邮箱、WhatsApp、咨询内容表单。
- 主导航：Shop / Today’s Design / Race Moment / About / FAQ / Contact，首页锚点平滑滚动。

商品详情页提供 `Style` 和 `Size` 两组变量。所有赛事、文章、价格和产品素材仍是结构占位，不会付款或向 Printful 发单。

## 运行预览

在项目根目录启动静态服务器，打开 `preview/index.html`。当前本地地址：

`http://127.0.0.1:8767/preview/index.html`

## WordPress 依赖

必需：

1. WooCommerce
2. APEXIK Story Engine（本项目提供）

上线前建议安装 Printful Integration for WooCommerce，并完成 `docs/ACCEPTANCE.md` 的生产验收。

## 当前边界

本阶段只实现结构与交互，不包括正式赛事内容、最终授权图、真实 Printful 同步、支付、税费、多语言和生产邮件接口。
