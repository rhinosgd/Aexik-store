<?php
/**
 * WooCommerce integration using hooks to minimize template drift.
 *
 * @package Apexik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_loop_shop_columns() {
	return 4;
}
add_filter( 'loop_shop_columns', 'apx_loop_shop_columns' );

function apx_loop_shop_per_page() {
	return 16;
}
add_filter( 'loop_shop_per_page', 'apx_loop_shop_per_page' );

function apx_woocommerce_wrapper_start() {
	echo '<main id="main" class="apx-main apx-commerce-main"><div class="apx-shell">';
}

function apx_woocommerce_wrapper_end() {
	echo '</div></main>';
}

function apx_replace_woocommerce_wrappers() {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	add_action( 'woocommerce_before_main_content', 'apx_woocommerce_wrapper_start', 10 );
	add_action( 'woocommerce_after_main_content', 'apx_woocommerce_wrapper_end', 10 );
}
add_action( 'after_setup_theme', 'apx_replace_woocommerce_wrappers' );

function apx_product_story_panel() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$story = $product->get_meta( '_apx_story_summary' );
	$moment_ids = array_filter( array_map( 'absint', explode( ',', (string) $product->get_meta( '_apx_related_moments' ) ) ) );
	$moment     = $moment_ids ? get_post( reset( $moment_ids ) ) : null;
	if ( ! $story && ! $moment ) {
		$story = __( 'Editorial story placeholder. Connect this product to an approved Race Moment in the APEXIK Story Engine.', 'apexik' );
	}
	?>
	<section class="apx-product-story" aria-labelledby="apx-product-story-title">
		<div><h2 id="apx-product-story-title"><?php esc_html_e( 'Made from race-day tension.', 'apexik' ); ?></h2></div>
		<div>
			<?php if ( $moment && 'publish' === $moment->post_status && 'apexik_moment' === $moment->post_type ) : ?><p class="apx-product-story__race"><a href="<?php echo esc_url( get_permalink( $moment ) ); ?>"><?php echo esc_html( sprintf( __( 'Read the Race Moment: %s', 'apexik' ), get_the_title( $moment ) ) ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></p><?php endif; ?>
			<p><?php echo esc_html( $story ); ?></p>
		</div>
	</section>
	<?php
}
add_action( 'woocommerce_after_single_product_summary', 'apx_product_story_panel', 8 );

function apx_cart_count_fragment( $fragments ) {
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$fragments['span.apx-cart-count'] = '<span class="apx-cart-count" aria-label="' . esc_attr( sprintf( _n( '%d item in cart', '%d items in cart', $count, 'apexik' ), $count ) ) . '">' . esc_html( $count ) . '</span>';
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'apx_cart_count_fragment' );

function apx_archive_intro() {
	if ( ! function_exists( 'is_shop' ) || ( ! is_shop() && ! is_product_category() ) ) {
		return;
	}
	?>
	<section class="apx-shop-intro">
		<p class="apx-shop-intro__count"><?php esc_html_e( 'Story-led objects for race fans', 'apexik' ); ?></p>
		<h1><?php echo esc_html( is_product_category() ? __( 'All Category', 'apexik' ) : __( 'Shop All', 'apexik' ) ); ?></h1>
		<p><?php esc_html_e( 'Choose the moment first, then the object you want to live with.', 'apexik' ); ?></p>
	</section>
	<?php
}
add_action( 'woocommerce_before_shop_loop', 'apx_archive_intro', 5 );

add_filter( 'woocommerce_show_page_title', '__return_false' );

function apx_woocommerce_product_classes( $classes, $product ) {
	$classes[] = 'apx-product-card';
	return $classes;
}
add_filter( 'woocommerce_post_class', 'apx_woocommerce_product_classes', 10, 2 );

remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

function apx_external_product_image( $html, $product, $size, $attr, $placeholder ) {
	if ( ! $product || $product->get_image_id() ) {
		return $html;
	}
	$url = $product->get_meta( '_apx_external_product_image' );
	if ( ! $url || 0 !== strpos( strtolower( $url ), 'https://' ) ) {
		return $html;
	}
	$attributes = wp_parse_args( $attr, array( 'class' => 'attachment-woocommerce_thumbnail size-woocommerce_thumbnail', 'loading' => 'lazy' ) );
	$attributes['src'] = $url;
	$attributes['alt'] = $product->get_name();
	return '<img ' . wc_implode_html_attributes( $attributes ) . '>';
}
add_filter( 'woocommerce_product_get_image', 'apx_external_product_image', 10, 5 );
