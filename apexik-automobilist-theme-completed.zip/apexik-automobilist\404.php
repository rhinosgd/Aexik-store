<?php
/** 404 template. */
get_header();
?>
<main id="main" class="apx-main"><section class="apx-404"><div class="apx-shell"><span>404</span><h1><?php esc_html_e( 'Wrong turn. Rejoin the circuit.', 'apexik' ); ?></h1><p><?php esc_html_e( 'The page moved, retired, or never made the starting grid.', 'apexik' ); ?></p><a class="apx-button" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Return home', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></div></section></main>
<?php get_footer(); ?>
