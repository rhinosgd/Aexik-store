<?php
/**
 * Template Name: APEXIK Campaign
 *
 * @package Apexik
 */
get_header();
?>
<main id="main" class="apx-main"><?php while ( have_posts() ) : the_post(); ?><header class="apx-campaign-hero"><div class="apx-shell"><h1><?php the_title(); ?></h1><div><?php the_excerpt(); ?></div><a class="apx-button apx-button--light" href="#campaign-products"><?php esc_html_e( 'See the collection', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></div></header><div class="apx-content"><?php the_content(); ?></div><section id="campaign-products" class="apx-section"><div class="apx-shell"><?php apx_render_product_loop( array( 'limit' => 8 ) ); ?></div></section><?php endwhile; ?></main>
<?php get_footer(); ?>
