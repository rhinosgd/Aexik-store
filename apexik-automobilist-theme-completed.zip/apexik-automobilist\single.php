<?php
/** Standard post template. */
get_header();
?>
<main id="main" class="apx-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<header class="apx-page-hero"><div class="apx-shell"><h1><?php the_title(); ?></h1><p><?php echo esc_html( get_the_date() ); ?></p><?php if ( has_excerpt() ) : ?><p><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?></div></header>
		<article <?php post_class( 'apx-content' ); ?>><?php the_content(); ?></article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
