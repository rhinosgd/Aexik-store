<?php
/**
 * Shared presentation helpers.
 *
 * @package Apexik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_icon( $name, $label = '' ) {
	$paths = array(
		'menu'    => '<path d="M3 6h18M3 12h18M3 18h18"/>',
		'close'   => '<path d="M5 5l14 14M19 5L5 19"/>',
		'search'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
		'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21c.7-4.2 3.4-6.3 8-6.3s7.3 2.1 8 6.3"/>',
		'bag'     => '<path d="M5 8h14l-1 13H6L5 8Z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/>',
		'arrow'   => '<path d="M5 12h14M14 7l5 5-5 5"/>',
		'chevron' => '<path d="m8 10 4 4 4-4"/>',
		'play'    => '<path d="m9 6 9 6-9 6V6Z"/>',
		'pause'   => '<path d="M9 6v12M15 6v12"/>',
		'prev'    => '<path d="M19 12H5m5 5-5-5 5-5"/>',
		'next'    => '<path d="M5 12h14m-5-5 5 5-5 5"/>',
		'external'=> '<path d="M14 5h5v5M19 5l-9 9"/><path d="M18 13v6H5V6h6"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	$aria = $label ? ' role="img" aria-label="' . esc_attr( $label ) . '"' : ' aria-hidden="true"';
	return '<svg class="apx-icon apx-icon--' . esc_attr( $name ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="square" stroke-linejoin="miter"' . $aria . '>' . $paths[ $name ] . '</svg>';
}

function apx_shop_url( $category = '' ) {
	if ( $category && function_exists( 'get_term_by' ) ) {
		$term = get_term_by( 'slug', $category, 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			return get_term_link( $term );
		}
		return home_url( '/product-category/' . sanitize_title( $category ) . '/' );
	}
	return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
}

function apx_placeholder_products() {
	return array(
		array( 'title' => 'Abu Dhabi 2021 — Lap 58', 'category' => 'Desk Mat', 'slug' => 'desk-mats', 'story_slug' => 'pit-wall', 'price' => '€39', 'image' => 'desk-mat-abu-dhabi-2021-artwork.png' ),
		array( 'title' => 'Hold Position?', 'category' => 'Clothing', 'slug' => 't-shirts', 'story_slug' => 'team-radio', 'price' => '€29', 'image' => 'product-tshirt.png' ),
		array( 'title' => 'Box This Lap', 'category' => 'Sticker', 'slug' => 'stickers', 'story_slug' => 'paddock-review', 'price' => '€9', 'image' => 'product-stickers.png' ),
		array( 'title' => 'One Lap Too Late', 'category' => 'Key Chain', 'slug' => 'keychains', 'story_slug' => 'driver-talk', 'price' => '€14', 'image' => 'product-keychain.png' ),
		array( 'title' => 'Paddock Review', 'category' => 'Curated Find', 'slug' => 'curated-finds', 'story_slug' => 'paddock-review', 'price' => '€24', 'image' => 'product-curated-mug.png' ),
		array( 'title' => 'Tyres Are Gone', 'category' => 'Clothing', 'slug' => 't-shirts', 'story_slug' => 'driver-talk', 'price' => '€29', 'image' => 'product-tshirt.png' ),
	);
}


function apx_render_placeholder_product( $product, $index = 0, $link_to_category = false, $link_taxonomy = 'product_cat' ) {
	$link = home_url( '/product/' . sanitize_title( $product['title'] ) . '/' );
	if ( $link_to_category && 'apx_story_type' === $link_taxonomy ) {
		$term = get_term_by( 'slug', $product['story_slug'], 'apx_story_type' );
		$link = $term && ! is_wp_error( $term ) ? get_term_link( $term ) : home_url( '/story-type/' . $product['story_slug'] . '/' );
	} elseif ( $link_to_category ) {
		$link = apx_shop_url( $product['slug'] );
	}
	?>
	<article class="apx-product-card apx-product-card--placeholder" data-category="<?php echo esc_attr( $product['slug'] ); ?>" data-story="<?php echo esc_attr( $product['story_slug'] ); ?>">
		<a class="apx-product-card__visual apx-product-card__visual--photo" href="<?php echo esc_url( $link ); ?>" aria-label="<?php echo esc_attr( $link_to_category ? sprintf( __( 'Browse the %s category', 'apexik' ), $product['category'] ) : sprintf( __( 'View %s', 'apexik' ), $product['title'] ) ); ?>">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/' . $product['image'] ); ?>" alt="<?php echo esc_attr( $product['title'] . ' ' . $product['category'] ); ?>">
		</a>
		<div class="apx-product-card__body">
			<div>
				<p><?php echo esc_html( $product['category'] ); ?></p>
				<h3><?php echo esc_html( $product['title'] ); ?></h3>
			</div>
			<strong><?php echo esc_html( $product['price'] ); ?></strong>
		</div>
	</article>
	<?php
}

function apx_render_product_loop( $args = array() ) {
	$defaults = array( 'limit' => 8, 'category' => '', 'story_type' => '', 'tag' => '', 'orderby' => 'date', 'include' => array(), 'link_to_category' => false, 'link_taxonomy' => 'product_cat' );
	$args     = wp_parse_args( $args, $defaults );
	if ( class_exists( 'WooCommerce' ) ) {
		$query_args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => absint( $args['limit'] ),
			'orderby'        => 'popularity' === $args['orderby'] ? 'meta_value_num' : $args['orderby'],
		);
		if ( ! empty( $args['include'] ) ) {
			$query_args['post__in'] = array_map( 'absint', (array) $args['include'] );
			$query_args['orderby']  = 'post__in';
		}
		if ( $args['category'] ) {
			$query_args['tax_query'] = array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => sanitize_title( $args['category'] ) ) );
		}
		if ( $args['story_type'] ) {
			$query_args['tax_query'] = array( array( 'taxonomy' => 'apx_story_type', 'field' => 'slug', 'terms' => sanitize_title( $args['story_type'] ) ) );
		}
		if ( 'popularity' === $args['orderby'] ) {
			$query_args['meta_key'] = 'total_sales';
		}
		$query = new WP_Query( $query_args );
		if ( $query->have_posts() ) {
			woocommerce_product_loop_start();
			if ( $args['link_to_category'] ) {
				$GLOBALS['apx_loop_link_taxonomy'] = $args['link_taxonomy'];
				add_filter( 'woocommerce_loop_product_link', 'apx_loop_category_link', 10, 2 );
			}
			while ( $query->have_posts() ) {
				$query->the_post();
				wc_get_template_part( 'content', 'product' );
			}
			if ( $args['link_to_category'] ) {
				remove_filter( 'woocommerce_loop_product_link', 'apx_loop_category_link', 10 );
				unset( $GLOBALS['apx_loop_link_taxonomy'] );
			}
			woocommerce_product_loop_end();
			wp_reset_postdata();
			return;
		}
		if ( ! empty( $args['include'] ) ) {
			echo '<p>' . esc_html__( 'No connected products are published yet.', 'apexik' ) . '</p>';
			return;
		}
	}
	$products = array_slice( apx_placeholder_products(), 0, absint( $args['limit'] ) );
	echo '<div class="apx-product-grid">';
	foreach ( $products as $index => $product ) {
		apx_render_placeholder_product( $product, $index, (bool) $args['link_to_category'], $args['link_taxonomy'] );
	}
	echo '</div>';
}

function apx_loop_category_link( $url, $product ) {
	$taxonomy = isset( $GLOBALS['apx_loop_link_taxonomy'] ) ? $GLOBALS['apx_loop_link_taxonomy'] : 'product_cat';
	$terms = get_the_terms( $product->get_id(), $taxonomy );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$link = get_term_link( reset( $terms ) );
		if ( ! is_wp_error( $link ) ) {
			return $link;
		}
	}
	return $url;
}

function apx_story_type_product_classes( $classes, $class, $post_id ) {
	if ( 'product' !== get_post_type( $post_id ) ) {
		return $classes;
	}
	$terms = get_the_terms( $post_id, 'apx_story_type' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$classes[] = 'apx_story_type-' . sanitize_html_class( $term->slug );
		}
	}
	return $classes;
}
add_filter( 'post_class', 'apx_story_type_product_classes', 10, 3 );

function apx_get_moment_meta( $post_id, $key, $fallback = '' ) {
	$value = get_post_meta( $post_id, '_apx_' . $key, true );
	return '' !== $value ? $value : $fallback;
}
