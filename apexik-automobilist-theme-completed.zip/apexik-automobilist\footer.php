<?php
/** Site footer. @package Apexik */
?>
<section class="apx-newsletter" aria-labelledby="apx-newsletter-title">
	<div class="apx-shell apx-newsletter__inner">
		<h2 id="apx-newsletter-title"><?php esc_html_e( 'The next story drops after the chequered flag.', 'apexik' ); ?></h2>
		<form class="apx-newsletter__form" data-newsletter-form novalidate><label for="apx-email"><?php esc_html_e( 'Email address', 'apexik' ); ?></label><div><input id="apx-email" type="email" name="email" autocomplete="email" placeholder="fan@example.com" required><button type="submit"><?php esc_html_e( 'Join the grid', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button></div><p class="apx-form-status" data-form-status aria-live="polite"></p></form>
	</div>
</section>

<section class="apx-trust-strip" aria-label="<?php esc_attr_e( 'Customer review service', 'apexik' ); ?>"><div class="apx-shell apx-trust-strip__inner"><strong>Trustpilot</strong><span><?php esc_html_e( 'Review score connects when the verified profile goes live.', 'apexik' ); ?></span></div></section>

<footer class="apx-footer">
	<div class="apx-shell">
		<div class="apx-footer__top"><div><a class="apx-logo apx-logo--footer" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span>APE</span><b>X</b><i>IK</i></a><p><?php esc_html_e( 'Paddock culture, engineered into objects for everyday life.', 'apexik' ); ?></p></div><nav class="apx-footer__social" aria-label="<?php esc_attr_e( 'Social channels', 'apexik' ); ?>"><a href="#" aria-label="Instagram">IG</a><a href="#" aria-label="TikTok">TT</a><a href="#" aria-label="YouTube">YT</a><a href="#" aria-label="Pinterest">PT</a></nav></div>
		<div class="apx-footer__grid">
			<div><h3><?php esc_html_e( 'Shop', 'apexik' ); ?></h3><a href="<?php echo esc_url( apx_shop_url( 'desk-mats' ) ); ?>"><?php esc_html_e( 'Desk Mats', 'apexik' ); ?></a><a href="<?php echo esc_url( apx_shop_url( 't-shirts' ) ); ?>"><?php esc_html_e( 'Clothing', 'apexik' ); ?></a><a href="<?php echo esc_url( apx_shop_url( 'stickers' ) ); ?>"><?php esc_html_e( 'Stickers', 'apexik' ); ?></a><a href="<?php echo esc_url( apx_shop_url( 'keychains' ) ); ?>"><?php esc_html_e( 'Key Chains', 'apexik' ); ?></a><a href="<?php echo esc_url( apx_shop_url( 'curated-finds' ) ); ?>"><?php esc_html_e( 'Curated Finds', 'apexik' ); ?></a></div>
			<div><h3><?php esc_html_e( 'Company', 'apexik' ); ?></h3><a href="<?php echo esc_url( home_url( '/#about' ) ); ?>"><?php esc_html_e( 'About Us', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/race-moments/' ) ); ?>"><?php esc_html_e( 'Race Moments', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/rights-and-sources/' ) ); ?>"><?php esc_html_e( 'Rights & Sources', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact', 'apexik' ); ?></a></div>
			<div><h3><?php esc_html_e( 'Help', 'apexik' ); ?></h3><a href="<?php echo esc_url( home_url( '/shipping/' ) ); ?>"><?php esc_html_e( 'Shipping & Delivery', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/returns/' ) ); ?>"><?php esc_html_e( 'Returns', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/size-guide/' ) ); ?>"><?php esc_html_e( 'Size Guide', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>"><?php esc_html_e( 'FAQ', 'apexik' ); ?></a></div>
			<div><h3><?php esc_html_e( 'Customer Service', 'apexik' ); ?></h3><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms & Conditions', 'apexik' ); ?></a><a href="<?php echo esc_url( home_url( '/cookies/' ) ); ?>"><?php esc_html_e( 'Cookie Settings', 'apexik' ); ?></a></div>
		</div>
		<div class="apx-footer__bottom"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> APEXIK</span><span><?php esc_html_e( 'Worldwide delivery · duties calculated at checkout', 'apexik' ); ?></span><div class="apx-footer__payments" aria-label="<?php esc_attr_e( 'Accepted payment methods', 'apexik' ); ?>"><span>VISA</span><span>MC</span><span>AMEX</span><span>PAYPAL</span><span>APPLE PAY</span></div></div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
