<?php
/** Shared taxonomy archive. */
require get_template_directory() . '/index.php';
