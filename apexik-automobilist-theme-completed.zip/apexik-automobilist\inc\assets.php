<?php
/**
 * Theme assets.
 *
 * @package Apexik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_enqueue_assets() {
	wp_enqueue_style(
		'apx-fonts',
		'https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,500;0,600;0,700;1,700&family=Manrope:wght@400;500;600;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'apx-site', APX_THEME_URI . '/assets/css/site.css', array(), APX_THEME_VERSION );
	wp_enqueue_script( 'apx-site', APX_THEME_URI . '/assets/js/site.js', array(), APX_THEME_VERSION, true );
	wp_localize_script( 'apx-site', 'apxTheme', array(
		'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
		'cartUrl'   => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ),
		'closeText' => __( 'Close', 'apexik' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'apx_enqueue_assets' );
