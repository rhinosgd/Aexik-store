<?php
/** Search results. */
get_header();
?>
<main id="main" class="apx-main"><header class="apx-page-hero"><div class="apx-shell"><h1><?php echo esc_html( sprintf( __( 'Results for “%s”', 'apexik' ), get_search_query() ) ); ?></h1><?php get_search_form(); ?></div></header><div class="apx-shell apx-post-list"><?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?><article class="apx-post-row"><p><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ?? __( 'Result', 'apexik' ) ); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article><?php endwhile; the_posts_pagination(); else : ?><p><?php esc_html_e( 'No results. Try a story title, team, driver or product type.', 'apexik' ); ?></p><?php endif; ?></div></main>
<?php get_footer(); ?>
