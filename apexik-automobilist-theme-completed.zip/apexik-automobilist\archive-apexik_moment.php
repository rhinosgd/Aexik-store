<?php
/** Race Moments archive. */
get_header();
?>
<main id="main" class="apx-main">
	<header class="apx-page-hero apx-moments-hero"><div class="apx-shell"><h1><?php esc_html_e( 'Race Moments', 'apexik' ); ?></h1><p><?php esc_html_e( 'Updated race reports, strategy explainers and radio stories. Editors can publish new articles after each race and connect every story to its product formats.', 'apexik' ); ?></p></div></header>
	<section class="apx-section"><div class="apx-shell">
		<nav class="apx-filter-bar" aria-label="<?php esc_attr_e( 'Filter moments', 'apexik' ); ?>"><a class="is-active" href="<?php echo esc_url( get_post_type_archive_link( 'apexik_moment' ) ); ?>"><?php esc_html_e( 'All moments', 'apexik' ); ?></a><?php wp_list_categories( array( 'taxonomy' => 'apx_story_type', 'title_li' => '', 'style' => 'list', 'echo' => true ) ); ?></nav>
		<div class="apx-moments__list">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article class="apx-moment-row">
					<a class="apx-moment-row__visual" href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'apx-moment' ); } else { ?><span><?php echo esc_html( str_pad( (string) get_the_ID(), 2, '0', STR_PAD_LEFT ) ); ?></span><i></i><?php } ?></a>
					<div class="apx-moment-row__copy"><p><time datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time> · <?php echo wp_kses_post( get_the_term_list( get_the_ID(), 'apx_story_type', '', ' · ' ) ?: __( 'Race Moment', 'apexik' ) ); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p><?php echo esc_html( get_the_excerpt() ); ?></p></div>
					<a class="apx-moment-row__action" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Read %s', 'apexik' ), get_the_title() ) ); ?>"><?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				</article>
			<?php endwhile; the_posts_pagination(); else : ?>
				<p><?php esc_html_e( 'The first approved Race Moments will appear here.', 'apexik' ); ?></p>
			<?php endif; ?>
		</div>
	</div></section>
</main>
<?php get_footer(); ?>
