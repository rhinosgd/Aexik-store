<?php
/**
 * Theme setup.
 *
 * @package Apexik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function apx_theme_setup() {
	load_theme_textdomain( 'apexik', APX_THEME_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 720,
		'single_image_width'    => 1440,
		'product_grid'          => array(
			'default_rows'    => 3,
			'min_rows'        => 1,
			'max_rows'        => 8,
			'default_columns' => 4,
			'min_columns'     => 1,
			'max_columns'     => 4,
		),
	) );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus( array(
		'primary' => __( 'Primary navigation', 'apexik' ),
		'footer'  => __( 'Footer navigation', 'apexik' ),
	) );

	add_image_size( 'apx-hero', 2200, 800, true );
	add_image_size( 'apx-product', 1600, 1600, true );
	add_image_size( 'apx-moment', 1600, 900, true );
}
add_action( 'after_setup_theme', 'apx_theme_setup' );

function apx_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Shop filters', 'apexik' ),
		'id'            => 'shop-filters',
		'before_widget' => '<section class="apx-filter-widget">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'apx_widgets_init' );

function apx_body_classes( $classes ) {
	$classes[] = 'apx-site';
	if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
		$classes[] = 'apx-commerce';
	}
	return $classes;
}
add_filter( 'body_class', 'apx_body_classes' );
