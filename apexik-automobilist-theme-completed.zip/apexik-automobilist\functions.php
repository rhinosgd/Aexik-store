<?php
/**
 * APEXIK theme bootstrap.
 *
 * @package Apexik
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'APX_THEME_VERSION', '1.1.0' );
define( 'APX_THEME_DIR', get_template_directory() );
define( 'APX_THEME_URI', get_template_directory_uri() );

require_once APX_THEME_DIR . '/inc/setup.php';
require_once APX_THEME_DIR . '/inc/assets.php';
require_once APX_THEME_DIR . '/inc/template-tags.php';
require_once APX_THEME_DIR . '/inc/commerce.php';
