<?php
/**
 * Site header.
 *
 * @package Apexik
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<!--
THESIS: Race-day stories become useful collectible objects; the site refuses a generic logo-merchandise grid.
OWN-WORLD: Warm paper, ink black, signal red and restrained gold; editorial scale, hard crop lines and pit-wall precision.
STORY: Visitors recognise a moment, understand the context, select a product format and move to checkout without losing the story.
FIRST VIEWPORT: A slim service bar and white navigation frame a full-width editorial race panel; oversized story title sits left and the product action anchors its lower edge.
FORM: Premium automotive editorial commerce, pinned by the approved Automobilist blueprint; Blueprint-A1-A.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
-->
<?php wp_body_open(); ?>
<?php if ( is_front_page() ) :
	$apx_intro_mode = get_option( 'apx_intro_mode', 'always' );
	$apx_intro_duration = max( 2200, min( 8000, absint( get_option( 'apx_intro_duration', 4200 ) ) ) );
	?>
	<div class="apx-grid-intro" data-grid-intro data-mode="<?php echo esc_attr( $apx_intro_mode ); ?>" data-duration="<?php echo esc_attr( $apx_intro_duration ); ?>" aria-hidden="true">
		<div class="apx-grid-intro__lights" aria-hidden="true"><?php for ( $apx_light = 0; $apx_light < 5; $apx_light++ ) : ?><span></span><?php endfor; ?></div>
		<p><?php esc_html_e( 'Welcome to Apexik', 'apexik' ); ?></p>
	</div>
<?php endif; ?>
<a class="apx-skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'apexik' ); ?></a>

<div class="apx-announcement" data-announcement>
	<div class="apx-shell apx-announcement__inner">
		<p><strong><?php esc_html_e( 'OPENING GRID', 'apexik' ); ?></strong> <?php esc_html_e( 'Free tracked delivery over €75 — placeholder offer', 'apexik' ); ?></p>
		<div class="apx-announcement__meta">
			<span><?php esc_html_e( 'Worldwide delivery', 'apexik' ); ?></span>
			<button type="button" data-announcement-close aria-label="<?php esc_attr_e( 'Close announcement', 'apexik' ); ?>"><?php echo apx_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
		</div>
	</div>
</div>

<header class="apx-header" data-header>
	<div class="apx-shell apx-header__inner">
		<button class="apx-header__menu" type="button" data-menu-open aria-controls="apx-mobile-menu" aria-expanded="false">
			<?php echo apx_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span><?php esc_html_e( 'Menu', 'apexik' ); ?></span>
		</button>

		<a class="apx-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'APEXIK home', 'apexik' ); ?>">
			<img src="<?php echo esc_url( APX_THEME_URI . '/assets/images/apexik-logo-polished.png' ); ?>" alt="APEXIK">
		</a>

		<nav class="apx-nav" aria-label="<?php esc_attr_e( 'Primary navigation', 'apexik' ); ?>">
			<div class="apx-nav__shop"><button type="button" aria-expanded="false" data-mega-trigger><?php esc_html_e( 'Shop', 'apexik' ); ?> <?php echo apx_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button><div class="apx-mega" data-mega-menu><div class="apx-shell apx-mega__grid"><div class="apx-mega__intro"><h2><?php esc_html_e( 'Shop by product', 'apexik' ); ?></h2><p><?php esc_html_e( 'One design system, built for different objects.', 'apexik' ); ?></p></div><ul><li><a href="<?php echo esc_url( apx_shop_url( 'desk-mats' ) ); ?>"><span>01</span><?php esc_html_e( 'Desk Mats', 'apexik' ); ?></a></li><li><a href="<?php echo esc_url( apx_shop_url( 't-shirts' ) ); ?>"><span>02</span><?php esc_html_e( 'Clothing', 'apexik' ); ?></a></li><li><a href="<?php echo esc_url( apx_shop_url( 'stickers' ) ); ?>"><span>03</span><?php esc_html_e( 'Stickers', 'apexik' ); ?></a></li><li><a href="<?php echo esc_url( apx_shop_url( 'keychains' ) ); ?>"><span>04</span><?php esc_html_e( 'Key Chains', 'apexik' ); ?></a></li><li><a href="<?php echo esc_url( apx_shop_url( 'curated-finds' ) ); ?>"><span>05</span><?php esc_html_e( 'Curated Finds', 'apexik' ); ?></a></li></ul><a class="apx-mega__feature apx-art apx-art--red" href="<?php echo esc_url( apx_shop_url() ); ?>"><span><?php esc_html_e( 'All products', 'apexik' ); ?></span><strong><?php esc_html_e( 'SHOP THE FULL GRID', 'apexik' ); ?></strong><small><?php esc_html_e( 'Open Shop All', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></small></a></div></div></div>
			<a href="<?php echo esc_url( home_url( '/#race-moment-news' ) ); ?>" data-home-anchor="race-moment-news"><?php esc_html_e( 'Race Moment', 'apexik' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>" data-home-anchor="faq"><?php esc_html_e( 'FAQ', 'apexik' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" data-home-anchor="contact"><?php esc_html_e( 'Contact', 'apexik' ); ?></a>
		</nav>

		<div class="apx-header__actions">
			<a href="<?php echo esc_url( home_url( '/?s=' ) ); ?>" aria-label="<?php esc_attr_e( 'Search', 'apexik' ); ?>"><?php echo apx_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			<a href="<?php echo esc_url( ( current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' ) ) ? home_url( '/apexik-control/' ) : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' ) ) ); ?>" aria-label="<?php esc_attr_e( 'Account', 'apexik' ); ?>"><?php echo apx_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			<button type="button" data-cart-open aria-controls="apx-cart-drawer" aria-expanded="false" aria-label="<?php esc_attr_e( 'Open cart', 'apexik' ); ?>">
				<?php echo apx_icon( 'bag' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="apx-cart-count"><?php echo function_exists( 'WC' ) && WC()->cart ? esc_html( WC()->cart->get_cart_contents_count() ) : '0'; ?></span>
			</button>
		</div>
	</div>
</header>

<div class="apx-promo-ticker" aria-label="<?php esc_attr_e( 'Current offers', 'apexik' ); ?>">
	<div class="apx-promo-ticker__track">
		<span><?php esc_html_e( 'Free shipping above $99', 'apexik' ); ?></span><span><?php esc_html_e( '50% off selected stories', 'apexik' ); ?></span><span><?php esc_html_e( 'Made to order', 'apexik' ); ?></span>
		<span aria-hidden="true"><?php esc_html_e( 'Free shipping above $99', 'apexik' ); ?></span><span aria-hidden="true"><?php esc_html_e( '50% off selected stories', 'apexik' ); ?></span><span aria-hidden="true"><?php esc_html_e( 'Made to order', 'apexik' ); ?></span>
	</div>
</div>

<div class="apx-mobile-menu" id="apx-mobile-menu" data-mobile-menu hidden>
	<div class="apx-mobile-menu__head">
		<img class="apx-logo-image" src="<?php echo esc_url( APX_THEME_URI . '/assets/images/apexik-logo-polished.png' ); ?>" alt="APEXIK">
		<button type="button" data-menu-close aria-label="<?php esc_attr_e( 'Close menu', 'apexik' ); ?>"><?php echo apx_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
	</div>
	<nav aria-label="<?php esc_attr_e( 'Mobile navigation', 'apexik' ); ?>">
		<a href="<?php echo esc_url( home_url( '/#shop-by-format' ) ); ?>" data-home-anchor="shop-by-format"><?php esc_html_e( 'Shop', 'apexik' ); ?><span>01</span></a>
		<a href="<?php echo esc_url( home_url( '/#race-moment-news' ) ); ?>" data-home-anchor="race-moment-news"><?php esc_html_e( 'Race Moment', 'apexik' ); ?><span>02</span></a>
		<a href="<?php echo esc_url( home_url( '/#faq' ) ); ?>" data-home-anchor="faq"><?php esc_html_e( 'FAQ', 'apexik' ); ?><span>03</span></a>
		<a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>" data-home-anchor="contact"><?php esc_html_e( 'Contact', 'apexik' ); ?><span>04</span></a>
	</nav>
</div>

<aside class="apx-cart-drawer" id="apx-cart-drawer" data-cart-drawer aria-hidden="true">
	<div class="apx-cart-drawer__head">
		<h2><?php esc_html_e( 'Your grid', 'apexik' ); ?></h2>
		<button type="button" data-cart-close aria-label="<?php esc_attr_e( 'Close cart', 'apexik' ); ?>"><?php echo apx_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
	</div>
	<div class="apx-cart-drawer__body">
		<?php if ( function_exists( 'woocommerce_mini_cart' ) ) : ?>
			<?php woocommerce_mini_cart(); ?>
		<?php else : ?>
			<div class="apx-cart-empty"><span>0</span><p><?php esc_html_e( 'No stories on your grid yet.', 'apexik' ); ?></p><a class="apx-button" href="<?php echo esc_url( apx_shop_url() ); ?>"><?php esc_html_e( 'Explore the shop', 'apexik' ); ?></a></div>
		<?php endif; ?>
	</div>
</aside>
<div class="apx-overlay" data-overlay hidden></div>
