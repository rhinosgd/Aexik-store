<?php
/**
 * Front page: eight-part Automobilist-inspired commerce structure.
 *
 * @package Apexik
 */

get_header();

$slides = array(
	array( 'code' => 'STORY 01 · STRATEGY', 'title' => 'THE UNDERCUT WINDOW', 'copy' => 'One lap. One gap. A decision that changed the order.', 'tone' => 'red' ),
	array( 'code' => 'STORY 02 · TEAM RADIO', 'title' => 'HOLD POSITION?', 'copy' => 'Two words, a long silence, and the entire fanbase listening.', 'tone' => 'navy' ),
	array( 'code' => 'STORY 03 · PIT WALL', 'title' => 'BOX THIS LAP', 'copy' => 'The call arrives. The crew moves before the sentence ends.', 'tone' => 'gold' ),
	array( 'code' => 'STORY 04 · DRIVER TALK', 'title' => 'TYRES ARE GONE', 'copy' => 'A familiar message. A very unfamiliar lap time.', 'tone' => 'black' ),
	array( 'code' => 'CURATED · RACE WEEK', 'title' => 'MADE AFTER SUNDAY', 'copy' => 'Small-run designs inspired by the tension of race day.', 'tone' => 'blue' ),
);
$slides[0]['code']  = get_option( 'apx_hero_kicker', $slides[0]['code'] );
$slides[0]['title'] = get_option( 'apx_hero_title', $slides[0]['title'] );
$slides[0]['copy']  = get_option( 'apx_hero_copy', $slides[0]['copy'] );
$hero_cta = get_option( 'apx_hero_cta', __( 'Explore the drop', 'apexik' ) );
$hero_image_id = absint( get_option( 'apx_hero_image_id', 0 ) );
$hero_image = $hero_image_id ? wp_get_attachment_image_url( $hero_image_id, 'apx-hero' ) : get_option( 'apx_hero_image_url', '' );
$banner_image_id = absint( get_option( 'apx_banner_image_id', 0 ) );
$banner_image = $banner_image_id ? wp_get_attachment_image_url( $banner_image_id, 'apx-hero' ) : get_option( 'apx_banner_image_url', '' );
?>
<main id="main" class="apx-main">
	<section class="apx-hero" data-carousel aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured race stories', 'apexik' ); ?>">
		<div class="apx-hero__track" data-carousel-track>
			<?php foreach ( $slides as $index => $slide ) : ?>
				<article class="apx-hero__slide apx-hero__slide--<?php echo esc_attr( $slide['tone'] ); ?>" data-slide aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>"<?php if ( 0 === $index && $hero_image ) : ?> style="background-image:linear-gradient(90deg,rgba(0,0,0,.78),rgba(0,0,0,.18)),url('<?php echo esc_url( $hero_image ); ?>')"<?php endif; ?>>
					<div class="apx-hero__geometry" aria-hidden="true"><span></span><span></span><span></span></div>
					<div class="apx-shell apx-hero__content">
						<p><?php echo esc_html( $slide['code'] ); ?></p>
						<h1><?php echo esc_html( $slide['title'] ); ?></h1>
						<div class="apx-hero__foot">
							<span><?php echo esc_html( $slide['copy'] ); ?></span>
							<a class="apx-button apx-button--light" href="<?php echo esc_url( apx_shop_url() ); ?>"><?php echo esc_html( $hero_cta ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						</div>
					</div>
					<span class="apx-hero__number"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				</article>
			<?php endforeach; ?>
		</div>
		<div class="apx-shell apx-hero__controls">
			<div class="apx-hero__dots" data-carousel-dots></div>
			<button type="button" data-carousel-toggle aria-label="<?php esc_attr_e( 'Pause slideshow', 'apexik' ); ?>" aria-pressed="false"><?php echo apx_icon( 'pause' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			<div class="apx-hero__arrows"><button type="button" data-carousel-prev aria-label="<?php esc_attr_e( 'Previous slide', 'apexik' ); ?>"><?php echo apx_icon( 'prev' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button><button type="button" data-carousel-next aria-label="<?php esc_attr_e( 'Next slide', 'apexik' ); ?>"><?php echo apx_icon( 'next' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button></div>
		</div>
	</section>

	<section id="today-design" class="apx-section apx-releases">
		<div class="apx-shell">
			<header class="apx-section-head"><div><h2><?php esc_html_e( 'New arrivals', 'apexik' ); ?></h2></div><a href="<?php echo esc_url( apx_shop_url() ); ?>"><?php esc_html_e( 'View all products', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></header>
			<?php apx_render_product_loop( array( 'limit' => 5, 'orderby' => 'date' ) ); ?>
		</div>
	</section>

	<section id="shop-by-format" class="apx-section apx-format-shop apx-five-product-row" data-product-tabs>
		<div class="apx-shell">
			<header class="apx-format-shop__header"><div><h2><?php esc_html_e( 'Shop All', 'apexik' ); ?></h2></div><p><?php esc_html_e( 'Choose a product category, then browse every available design in that collection.', 'apexik' ); ?></p></header>
			<div class="apx-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Shop by product type', 'apexik' ); ?>">
				<?php foreach ( array( 'all' => 'ALL', 't-shirts' => 'CLOTHING', 'desk-mats' => 'DESK MATS', 'stickers' => 'STICKERS', 'keychains' => 'KEY CHAINS', 'curated-finds' => 'CURATED FINDS' ) as $slug => $label ) : ?>
					<button id="apx-tab-<?php echo esc_attr( $slug ); ?>" type="button" role="tab" aria-controls="apx-product-panel" tabindex="<?php echo 'all' === $slug ? '0' : '-1'; ?>" aria-selected="<?php echo 'all' === $slug ? 'true' : 'false'; ?>" data-product-tab="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></button>
				<?php endforeach; ?>
			</div>
			<div id="apx-product-panel" role="tabpanel" aria-labelledby="apx-tab-all"><?php apx_render_product_loop( array( 'limit' => 5, 'orderby' => 'popularity', 'link_to_category' => true ) ); ?></div>
		</div>
	</section>

	<section id="race-moment-news" class="apx-section apx-race-news" data-race-news>
		<div class="apx-shell">
			<header class="apx-section-head"><div><h2><?php esc_html_e( 'Race Moments', 'apexik' ); ?></h2></div><a href="<?php echo esc_url( get_post_type_archive_link( 'apexik_moment' ) ?: home_url( '/race-moments/' ) ); ?>"><?php esc_html_e( 'All articles', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></header>
			<?php
			$fallback_articles = array(
				array( 'The Undercut Window', 'Pit Wall', 'moment-pit-wall.png' ),
				array( 'Hold Position?', 'Team Radio', 'moment-team-radio.png' ),
				array( 'Tyres Are Gone', 'Driver Talk', 'moment-driver-talk.png' ),
				array( 'Inside the Garage Window', 'Race Report', 'moment-garage.png' ),
				array( 'The Paddock Review', 'Paddock Review', 'moment-paddock-review.png' ),
			);
			$news_query = new WP_Query( array( 'post_type' => 'apexik_moment', 'post_status' => 'publish', 'posts_per_page' => 5 ) );
			$first_image = get_template_directory_uri() . '/assets/images/moment-pit-wall.png';
			$first_link = get_post_type_archive_link( 'apexik_moment' ) ?: home_url( '/race-moments/' );
			?>
			<div class="apx-race-news__layout">
				<a class="apx-race-news__visual" href="<?php echo esc_url( $first_link ); ?>" data-race-news-visual><img src="<?php echo esc_url( $first_image ); ?>" alt="<?php esc_attr_e( 'Race Moment editorial placeholder', 'apexik' ); ?>" data-race-news-image></a>
				<div class="apx-race-news__list">
					<?php if ( $news_query->have_posts() ) : $article_index = 0; while ( $news_query->have_posts() ) : $news_query->the_post(); $fallback_image = get_template_directory_uri() . '/assets/images/' . $fallback_articles[ $article_index % count( $fallback_articles ) ][2]; $image = get_the_post_thumbnail_url( get_the_ID(), 'apx-moment' ) ?: $fallback_image; ?>
						<article data-race-news-item data-image="<?php echo esc_url( $image ); ?>" data-link="<?php the_permalink(); ?>"><span><?php echo esc_html( get_the_date() ); ?></span><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3></article>
					<?php $article_index++; endwhile; wp_reset_postdata(); else : ?>
						<?php foreach ( $fallback_articles as $article ) : $article_link = home_url( '/race-moments/' ); $article_image = get_template_directory_uri() . '/assets/images/' . $article[2]; ?>
							<article data-race-news-item data-image="<?php echo esc_url( $article_image ); ?>" data-link="<?php echo esc_url( $article_link ); ?>"><span><?php echo esc_html( $article[1] . ' · Placeholder' ); ?></span><h3><a href="<?php echo esc_url( $article_link ); ?>"><?php echo esc_html( $article[0] ); ?></a></h3></article>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<section id="paddock-fun" class="apx-section apx-moments apx-five-product-row" data-product-tabs>
		<div class="apx-shell">
			<header class="apx-format-shop__header"><div><h2><?php esc_html_e( 'Paddock’s Fun & Meme', 'apexik' ); ?></h2></div><p><?php esc_html_e( 'Browse designs by the paddock culture, radio lines and trackside details behind them.', 'apexik' ); ?></p></header>
			<div class="apx-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Browse paddock story products', 'apexik' ); ?>">
				<?php foreach ( array( 'all' => 'All Story', 'pit-wall' => 'Pit Wall', 'team-radio' => 'Team Radio', 'driver-talk' => 'Driver Talk', 'paddock-review' => 'Paddock Review' ) as $slug => $label ) : ?>
					<button id="apx-moment-tab-<?php echo esc_attr( $slug ); ?>" type="button" role="tab" aria-controls="apx-moment-product-panel" tabindex="<?php echo 'all' === $slug ? '0' : '-1'; ?>" aria-selected="<?php echo 'all' === $slug ? 'true' : 'false'; ?>" data-product-tab="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></button>
				<?php endforeach; ?>
			</div>
			<div id="apx-moment-product-panel" role="tabpanel" aria-labelledby="apx-moment-tab-all"><?php apx_render_product_loop( array( 'limit' => 5, 'orderby' => 'date', 'link_to_category' => true, 'link_taxonomy' => 'apx_story_type' ) ); ?></div>
		</div>
	</section>

	<section class="apx-proof"<?php if ( $banner_image ) : ?> style="background-image:linear-gradient(rgba(0,0,0,.76),rgba(0,0,0,.76)),url('<?php echo esc_url( $banner_image ); ?>')"<?php endif; ?>>
		<div class="apx-shell apx-proof__grid">
			<div><strong>01</strong><h2><?php esc_html_e( 'Made it happen', 'apexik' ); ?></h2><p><?php esc_html_e( 'Built from the paddock up.', 'apexik' ); ?></p></div>
			<div><strong>02</strong><h2><?php esc_html_e( 'Designed as a system', 'apexik' ); ?></h2><p><?php esc_html_e( 'The same moment adapts to each product instead of being copied blindly.', 'apexik' ); ?></p></div>
			<div><strong>03</strong><h2><?php esc_html_e( 'Made on demand', 'apexik' ); ?></h2><p><?php esc_html_e( 'Printful-ready variants keep the launch inventory intentionally lean.', 'apexik' ); ?></p></div>
		</div>
	</section>

	<section id="about" class="apx-about"><div class="apx-shell apx-about__inner"><div class="apx-about__lead"><h2><?php esc_html_e( 'About Us', 'apexik' ); ?></h2><h3><?php esc_html_e( 'Built from the paddock up', 'apexik' ); ?></h3><strong><?php esc_html_e( 'For the ones who never left.', 'apexik' ); ?></strong></div><div class="apx-about__copy"><p><?php echo wp_kses_post( __( 'We don’t just make mousepads. Or desk mats. Or tees, mugs, stickers, keychains. We make <b>touchpoints</b> — little pieces of the paddock that live on your desk, in your hand, on your car, in your daily life.', 'apexik' ) ); ?></p><p><?php esc_html_e( 'Because motorsport culture doesn’t stay at the track. It follows you home. It spreads across your desk while you work. It rides shotgun on your keychain. It sticks to your laptop, your water bottle, your rear window. It shows up in the mug you’re holding at 2 a.m. chasing a deadline.', 'apexik' ); ?></p><p><?php esc_html_e( 'That’s the whole point. We’re not selling products. We’re selling the feeling of being there — the tension on the grid before lights out, the radio chatter in your ear, the pit wall lit up with data, the paddock buzzing with people who live and breathe this sport.', 'apexik' ); ?></p><p><?php echo wp_kses_post( __( 'Every design starts with the same question: <em>Does this carry the culture?</em> Not “does it look cool” — cool is easy. Culture is earned.', 'apexik' ) ); ?></p><p><?php esc_html_e( 'So we study the details: tire marks, sector times, team colors, pit-board typography, and the way a helmet visor catches the light. We put those fragments where you’ll see them every day.', 'apexik' ); ?></p><p><?php esc_html_e( 'Because being a fan isn’t a weekend thing. It’s a lifestyle. And your desk, your car, your gear — they should reflect that.', 'apexik' ); ?></p></div></div></section>

	<section id="faq" class="apx-section apx-faq">
		<div class="apx-shell">
			<header class="apx-section-head"><div><h2><?php esc_html_e( 'FAQ', 'apexik' ); ?></h2></div><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>"><?php esc_html_e( 'View all answers', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></header>
			<div class="apx-faq__list">
				<details><summary><?php esc_html_e( 'Are these official licensed products?', 'apexik' ); ?></summary><p><?php esc_html_e( 'APEXIK works from approved source material. Final rights and product details will be published before launch.', 'apexik' ); ?></p></details>
				<details><summary><?php esc_html_e( 'How are products made?', 'apexik' ); ?></summary><p><?php esc_html_e( 'The MVP uses made-to-order production through Printful to keep inventory lean.', 'apexik' ); ?></p></details>
				<details><summary><?php esc_html_e( 'Which regions do you ship to?', 'apexik' ); ?></summary><p><?php esc_html_e( 'The launch targets Europe, the United States, Japan, Australia and Brazil. Exact rates remain placeholder content.', 'apexik' ); ?></p></details>
			</div>
		</div>
	</section>

	<section id="contact" class="apx-contact"><div class="apx-shell"><div class="apx-contact__inner"><h2><?php esc_html_e( 'Need a race-day answer?', 'apexik' ); ?></h2><div><p><?php esc_html_e( 'Questions about products, delivery, licensing or an order can be handled from one contact point.', 'apexik' ); ?></p><button class="apx-button apx-button--light" type="button" data-contact-toggle aria-expanded="false" aria-controls="apx-contact-form"><?php esc_html_e( 'Contact us', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button></div></div><form id="apx-contact-form" class="apx-contact-form" data-contact-form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" hidden><input type="hidden" name="action" value="apx_submit_inquiry"><?php wp_nonce_field( 'apx_submit_inquiry' ); ?><label class="apx-honeypot" aria-hidden="true">Company<input type="text" name="company" tabindex="-1" autocomplete="off"></label><label><?php esc_html_e( 'Name', 'apexik' ); ?><input type="text" name="name" autocomplete="name"></label><label><?php esc_html_e( 'Email', 'apexik' ); ?> *<input type="email" name="email" autocomplete="email" required></label><label><?php esc_html_e( 'WhatsApp', 'apexik' ); ?><input type="tel" name="whatsapp" autocomplete="tel"></label><label class="apx-contact-form__message"><?php esc_html_e( 'What can we help with?', 'apexik' ); ?><textarea name="message" rows="4" required></textarea></label><button class="apx-button apx-button--light" type="submit"><?php esc_html_e( 'Send enquiry', 'apexik' ); ?></button><p class="apx-form-status" data-contact-status aria-live="polite"><?php if ( isset( $_GET['contact'] ) && 'sent' === sanitize_key( wp_unslash( $_GET['contact'] ) ) ) { esc_html_e( 'Your enquiry has been sent.', 'apexik' ); } elseif ( isset( $_GET['contact'] ) && 'wait' === sanitize_key( wp_unslash( $_GET['contact'] ) ) ) { esc_html_e( 'Please wait one minute before sending again.', 'apexik' ); } elseif ( isset( $_GET['contact'] ) && 'invalid' === sanitize_key( wp_unslash( $_GET['contact'] ) ) ) { esc_html_e( 'Please check your email and message.', 'apexik' ); } ?></p></form></div></section>
</main>
<?php get_footer(); ?>
