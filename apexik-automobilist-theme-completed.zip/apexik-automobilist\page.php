<?php
/** Standard page template. */
get_header();
?>
<main id="main" class="apx-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<?php if ( is_page( 'about' ) ) : ?>
			<section class="apx-about apx-about--page"><div class="apx-shell apx-about__inner"><div class="apx-about__lead"><h1><?php esc_html_e( 'About Us', 'apexik' ); ?></h1><h3><?php esc_html_e( 'Built from the paddock up', 'apexik' ); ?></h3><strong><?php esc_html_e( 'For the ones who never left.', 'apexik' ); ?></strong></div><div class="apx-about__copy"><p><?php echo wp_kses_post( __( 'We don’t just make mousepads. Or desk mats. Or tees, mugs, stickers, keychains. We make <b>touchpoints</b> — little pieces of the paddock that live on your desk, in your hand, on your car, in your daily life.', 'apexik' ) ); ?></p><p><?php esc_html_e( 'Because motorsport culture doesn’t stay at the track. It follows you home. It spreads across your desk while you work. It rides shotgun on your keychain. It sticks to your laptop, your water bottle, your rear window. It shows up in the mug you’re holding at 2 a.m. chasing a deadline.', 'apexik' ); ?></p><p><?php esc_html_e( 'That’s the whole point. We’re not selling products. We’re selling the feeling of being there — the tension on the grid before lights out, the radio chatter in your ear, the pit wall lit up with data, the paddock buzzing with people who live and breathe this sport.', 'apexik' ); ?></p><p><?php echo wp_kses_post( __( 'Every design starts with the same question: <em>Does this carry the culture?</em> Not “does it look cool” — cool is easy. Culture is earned.', 'apexik' ) ); ?></p><p><?php esc_html_e( 'So we study the details: tire marks, sector times, team colors, pit-board typography, and the way a helmet visor catches the light. We put those fragments where you’ll see them every day.', 'apexik' ); ?></p><p><?php esc_html_e( 'Because being a fan isn’t a weekend thing. It’s a lifestyle. And your desk, your car, your gear — they should reflect that.', 'apexik' ); ?></p></div></div></section>
		<?php else : ?>
			<header class="apx-page-hero"><div class="apx-shell"><h1><?php the_title(); ?></h1></div></header>
			<article <?php post_class( 'apx-content' ); ?>><?php the_content(); ?></article>
		<?php endif; ?>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
