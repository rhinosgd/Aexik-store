(() => {
  'use strict';

  const body = document.body;
  const gridIntro = document.querySelector('[data-grid-intro]');
  if (gridIntro) {
    const mode = gridIntro.dataset.mode || 'always';
    const alreadySeen = sessionStorage.getItem('apx_intro_seen') === '1';
    if (mode === 'off' || (mode === 'first' && alreadySeen) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      gridIntro.remove();
    } else {
      const duration = Math.max(2200, Math.min(8000, Number(gridIntro.dataset.duration) || 4200));
      document.documentElement.classList.add('apx-intro-active');
      requestAnimationFrame(() => gridIntro.classList.add('is-running'));
      window.setTimeout(() => {
        gridIntro.classList.add('is-finished');
        document.documentElement.classList.remove('apx-intro-active');
        sessionStorage.setItem('apx_intro_seen', '1');
        window.setTimeout(() => gridIntro.remove(), 650);
      }, duration);
    }
  }
  const overlay = document.querySelector('[data-overlay]');
  let lastTrigger = null;
  let activePanel = null;
  let inerted = [];

  const setBackgroundInert = (panel, open) => {
    if (open) {
	  const panelParent = panel.parentElement;
	  const nearSiblings = panelParent ? [...panelParent.children].filter((item) => item !== panel && item !== overlay) : [];
	  const bodySiblings = [...body.children].filter((item) => item !== panelParent && item !== panel && item !== overlay);
	  inerted = [...new Set([...nearSiblings, ...bodySiblings])];
      inerted.forEach((item) => item.setAttribute('inert', ''));
    } else {
      inerted.forEach((item) => item.removeAttribute('inert'));
      inerted = [];
    }
  };

  const setOverlay = (open) => {
    if (!overlay) return;
    overlay.hidden = false;
    requestAnimationFrame(() => overlay.classList.toggle('is-open', open));
    if (!open) window.setTimeout(() => { overlay.hidden = true; }, 310);
    body.classList.toggle('apx-lock', open);
  };

  const togglePanel = (panel, trigger, open) => {
    if (!panel) return;
    panel.hidden = false;
    panel.classList.toggle('is-open', open);
    panel.setAttribute('aria-hidden', String(!open));
    if (trigger) trigger.setAttribute('aria-expanded', String(open));
    if (open) {
      lastTrigger = trigger;
      activePanel = panel;
      setBackgroundInert(panel, true);
      setOverlay(true);
      const first = panel.querySelector('button, a, input, select, textarea');
      if (first) window.setTimeout(() => first.focus(), 80);
    } else {
      window.setTimeout(() => { if (panel.hasAttribute('hidden')) panel.hidden = true; }, 430);
      setOverlay(false);
      if (activePanel === panel) {
        activePanel = null;
        setBackgroundInert(panel, false);
      }
      if (lastTrigger) lastTrigger.focus();
    }
  };

  const announcement = document.querySelector('[data-announcement]');
  const announcementClose = document.querySelector('[data-announcement-close]');
  if (announcement && document.cookie.includes('apx_announcement_closed=1')) announcement.hidden = true;
  announcementClose?.addEventListener('click', () => {
    announcement.hidden = true;
    document.cookie = 'apx_announcement_closed=1;path=/;max-age=604800;SameSite=Lax';
  });

  const megaTrigger = document.querySelector('[data-mega-trigger]');
  const megaMenu = document.querySelector('[data-mega-menu]');
  const closeMega = () => {
    megaMenu?.classList.remove('is-open');
    megaTrigger?.setAttribute('aria-expanded', 'false');
  };
  megaTrigger?.addEventListener('click', () => {
    const open = megaTrigger.getAttribute('aria-expanded') !== 'true';
    megaTrigger.setAttribute('aria-expanded', String(open));
    megaMenu?.classList.toggle('is-open', open);
  });

  const mobileMenu = document.querySelector('[data-mobile-menu]');
  const menuOpen = document.querySelector('[data-menu-open]');
  document.querySelector('[data-menu-close]')?.addEventListener('click', () => togglePanel(mobileMenu, menuOpen, false));
  menuOpen?.addEventListener('click', () => togglePanel(mobileMenu, menuOpen, true));

  const cartDrawer = document.querySelector('[data-cart-drawer]');
  const cartOpen = document.querySelector('[data-cart-open]');
  document.querySelector('[data-cart-close]')?.addEventListener('click', () => togglePanel(cartDrawer, cartOpen, false));
  cartOpen?.addEventListener('click', () => togglePanel(cartDrawer, cartOpen, true));
  overlay?.addEventListener('click', () => {
    togglePanel(mobileMenu, menuOpen, false);
    togglePanel(cartDrawer, cartOpen, false);
    closeMega();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Tab' && activePanel) {
      const focusable = [...activePanel.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')];
      if (focusable.length) {
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    if (event.key !== 'Escape') return;
    togglePanel(mobileMenu, menuOpen, false);
    togglePanel(cartDrawer, cartOpen, false);
    closeMega();
  });
  document.addEventListener('click', (event) => {
    if (megaMenu && megaTrigger && !megaMenu.contains(event.target) && !megaTrigger.contains(event.target)) closeMega();
  });

  document.querySelectorAll('[data-carousel]').forEach((carousel) => {
    const slides = [...carousel.querySelectorAll('[data-slide]')];
    const dotsHost = carousel.querySelector('[data-carousel-dots]');
    const toggle = carousel.querySelector('[data-carousel-toggle]');
    let index = 0;
    let paused = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let timer;

    const show = (next) => {
      index = (next + slides.length) % slides.length;
      slides.forEach((slide, i) => {
        const hidden = i !== index;
        slide.setAttribute('aria-hidden', String(hidden));
        slide.querySelectorAll('a, button, input, select, textarea, [tabindex]').forEach((item) => {
          if (hidden) {
            if (!item.hasAttribute('data-apx-tabindex')) item.setAttribute('data-apx-tabindex', item.getAttribute('tabindex') ?? '');
            item.setAttribute('tabindex', '-1');
          } else if (item.hasAttribute('data-apx-tabindex')) {
            const original = item.getAttribute('data-apx-tabindex');
            if (original) item.setAttribute('tabindex', original); else item.removeAttribute('tabindex');
            item.removeAttribute('data-apx-tabindex');
          }
        });
      });
      dotsHost?.querySelectorAll('button').forEach((dot, i) => dot.setAttribute('aria-current', String(i === index)));
    };
    const schedule = () => {
      window.clearInterval(timer);
      if (!paused && slides.length > 1) timer = window.setInterval(() => show(index + 1), 6500);
    };
    slides.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.setAttribute('aria-label', `Show slide ${i + 1}`);
      dot.setAttribute('aria-current', String(i === 0));
      dot.addEventListener('click', () => { show(i); schedule(); });
      dotsHost?.appendChild(dot);
    });
    carousel.querySelector('[data-carousel-prev]')?.addEventListener('click', () => { show(index - 1); schedule(); });
    carousel.querySelector('[data-carousel-next]')?.addEventListener('click', () => { show(index + 1); schedule(); });
    toggle?.addEventListener('click', () => {
      paused = !paused;
      toggle.setAttribute('aria-pressed', String(paused));
      toggle.setAttribute('aria-label', paused ? 'Play slideshow' : 'Pause slideshow');
      toggle.innerHTML = paused
        ? '<svg class="apx-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="m9 6 9 6-9 6V6Z"/></svg>'
        : '<svg class="apx-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M9 6v12M15 6v12"/></svg>';
      schedule();
    });
    carousel.addEventListener('pointerenter', () => window.clearInterval(timer));
    carousel.addEventListener('pointerleave', schedule);
    show(0);
    schedule();
  });

  document.querySelectorAll('[data-product-tabs]').forEach((section) => {
    const tabs = [...section.querySelectorAll('[data-product-tab]')];
    const cards = [...section.querySelectorAll('.apx-product-card, li.product')];
    const panel = section.querySelector('[role="tabpanel"]');
    const selectTab = (tab) => {
      tabs.forEach((item) => item.setAttribute('aria-selected', String(item === tab)));
      tabs.forEach((item) => item.setAttribute('tabindex', item === tab ? '0' : '-1'));
      if (panel) panel.setAttribute('aria-labelledby', tab.id);
      const filter = tab.dataset.productTab;
      let shown = 0;
      cards.forEach((card) => {
        const visible = 'all' === filter || card.dataset.category === filter || card.dataset.story === filter || card.classList.contains(`product_cat-${filter}`) || card.classList.contains(`apx_story_type-${filter}`);
        card.hidden = !visible || shown >= 5;
        if (visible) shown += 1;
      });
    };
    tabs.forEach((tab, tabIndex) => {
      tab.addEventListener('click', () => selectTab(tab));
      tab.addEventListener('keydown', (event) => {
        if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        event.preventDefault();
        let next = tabIndex;
        if (event.key === 'ArrowLeft') next = (tabIndex - 1 + tabs.length) % tabs.length;
        if (event.key === 'ArrowRight') next = (tabIndex + 1) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        tabs[next].focus();
        selectTab(tabs[next]);
      });
    });
    const requestedCategory = new URLSearchParams(window.location.search).get('category');
    const requestedTab = requestedCategory ? tabs.find((tab) => tab.dataset.productTab === requestedCategory) : null;
    selectTab(requestedTab || tabs.find((tab) => tab.getAttribute('aria-selected') === 'true') || tabs[0]);
  });

  document.querySelectorAll('[data-newsletter-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const input = form.querySelector('input[type="email"]');
      const status = form.querySelector('[data-form-status]');
      if (!input?.checkValidity()) {
        status.textContent = 'Enter a valid email address to join the grid.';
        input?.focus();
        return;
      }
      status.textContent = 'You are on the grid. Connect this form to Klaviyo or Mailchimp before launch.';
      form.reset();
    });
  });

  document.querySelectorAll('[data-race-news]').forEach((section) => {
    const image = section.querySelector('[data-race-news-image]');
    const visual = section.querySelector('[data-race-news-visual]');
    const items = [...section.querySelectorAll('[data-race-news-item]')];
    const activate = (item) => {
      items.forEach((candidate) => candidate.classList.toggle('is-active', candidate === item));
      if (visual && item.dataset.link) visual.href = item.dataset.link;
      if (image && item.dataset.image && image.src !== item.dataset.image) {
        image.style.opacity = '.35';
        window.setTimeout(() => {
          image.src = item.dataset.image;
          image.style.opacity = '1';
        }, 130);
      }
    };
    items.forEach((item) => {
      item.addEventListener('pointerenter', () => activate(item));
      item.addEventListener('focusin', () => activate(item));
    });
    if (items[0]) activate(items[0]);
  });

  const contactToggle = document.querySelector('[data-contact-toggle]');
  const contactForm = document.querySelector('[data-contact-form]');
  contactToggle?.addEventListener('click', () => {
    const open = contactToggle.getAttribute('aria-expanded') !== 'true';
    contactToggle.setAttribute('aria-expanded', String(open));
    if (contactForm) contactForm.hidden = !open;
    if (open) contactForm?.querySelector('input')?.focus();
  });
  contactForm?.addEventListener('submit', (event) => {
    if (!document.body.classList.contains('preview-page')) return;
    event.preventDefault();
    const status = contactForm.querySelector('[data-contact-status]');
    if (!contactForm.reportValidity()) return;
    if (status) status.textContent = 'Enquiry captured in the prototype. Connect this form to the production inbox before launch.';
  });

  const homeAnchors = [...document.querySelectorAll('[data-home-anchor]')];
  homeAnchors.forEach((link) => {
    link.addEventListener('click', (event) => {
      const target = document.getElementById(link.dataset.homeAnchor);
      if (!target) return;
      event.preventDefault();
      if (mobileMenu?.classList.contains('is-open')) togglePanel(mobileMenu, menuOpen, false);
      target.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
      window.history.replaceState(null, '', `#${target.id}`);
    });
  });
  const anchorTargets = homeAnchors.map((link) => document.getElementById(link.dataset.homeAnchor)).filter(Boolean);
  if ('IntersectionObserver' in window && anchorTargets.length) {
    const anchorObserver = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      homeAnchors.forEach((link) => link.classList.toggle('is-current', link.dataset.homeAnchor === visible.target.id));
    }, { rootMargin: '-30% 0px -55% 0px', threshold: [0, .2, .6] });
    anchorTargets.forEach((target) => anchorObserver.observe(target));
  }
})();
