<?php
/** Single Race Moment. */
get_header();
?>
<main id="main" class="apx-main">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'apx-moment-single' ); ?>>
			<header class="apx-moment-single__hero">
				<div class="apx-shell"><div class="apx-moment-single__meta"><span><?php echo esc_html( apx_get_moment_meta( get_the_ID(), 'event_date', get_the_date() ) ); ?></span><span><?php echo wp_kses_post( get_the_term_list( get_the_ID(), 'apx_story_type', '', ' / ' ) ); ?></span></div><h1><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?></div>
			</header>
			<?php if ( has_post_thumbnail() ) : ?><div class="apx-shell apx-moment-single__image"><?php the_post_thumbnail( 'apx-hero' ); ?></div><?php endif; ?>
			<div class="apx-moment-single__body">
				<aside><h2><?php esc_html_e( 'Source record', 'apexik' ); ?></h2><dl><dt><?php esc_html_e( 'Source', 'apexik' ); ?></dt><dd><?php $source_url = apx_get_moment_meta( get_the_ID(), 'source_url' ); $source_title = apx_get_moment_meta( get_the_ID(), 'source_title', __( 'Pending publication', 'apexik' ) ); if ( $source_url ) : ?><a href="<?php echo esc_url( $source_url ); ?>" rel="noopener noreferrer"><?php echo esc_html( $source_title ); ?> <?php echo apx_icon( 'external' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a><?php else : echo esc_html( $source_title ); endif; ?></dd><dt><?php esc_html_e( 'Reference', 'apexik' ); ?></dt><dd><?php echo esc_html( apx_get_moment_meta( get_the_ID(), 'reference_timestamp', '—' ) ); ?></dd><dt><?php esc_html_e( 'Rights status', 'apexik' ); ?></dt><dd><?php echo esc_html( apx_get_moment_meta( get_the_ID(), 'rights_status', 'draft' ) ); ?></dd></dl></aside>
				<div class="apx-content"><?php $quote = apx_get_moment_meta( get_the_ID(), 'radio_quote' ); if ( $quote ) : ?><blockquote><?php echo esc_html( $quote ); ?></blockquote><?php endif; ?><?php the_content(); ?></div>
			</div>
			<?php $related_ids = array_filter( array_map( 'absint', explode( ',', apx_get_moment_meta( get_the_ID(), 'related_products' ) ) ) ); ?>
			<section class="apx-section apx-related-products"><div class="apx-shell"><header class="apx-section-head"><div><h2><?php esc_html_e( 'Shop this story', 'apexik' ); ?></h2><p><?php esc_html_e( 'Carry the same race moment across four product formats.', 'apexik' ); ?></p></div><a href="<?php echo esc_url( apx_shop_url() ); ?>"><?php esc_html_e( 'View all products', 'apexik' ); ?></a></header><?php if ( $related_ids ) { apx_render_product_loop( array( 'limit' => 4, 'include' => $related_ids ) ); } else { apx_render_product_loop( array( 'limit' => 4, 'orderby' => 'date' ) ); } ?></div></section>
		</article>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
