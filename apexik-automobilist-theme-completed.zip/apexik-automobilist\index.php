<?php
/**
 * Default template.
 *
 * @package Apexik
 */
get_header();
?>
<main id="main" class="apx-main">
	<header class="apx-page-hero"><div class="apx-shell"><h1><?php echo esc_html( is_archive() ? get_the_archive_title() : __( 'Stories', 'apexik' ) ); ?></h1><?php the_archive_description( '<div>', '</div>' ); ?></div></header>
	<div class="apx-shell apx-post-list">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<article <?php post_class( 'apx-post-row' ); ?>><p><?php echo esc_html( get_the_date() ); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><div><?php the_excerpt(); ?></div><a href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read story', 'apexik' ); ?> <?php echo apx_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a></article>
		<?php endwhile; the_posts_pagination(); else : ?>
			<p><?php esc_html_e( 'No stories published yet.', 'apexik' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
