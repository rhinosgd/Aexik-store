<?php
/**
 * Template Name: APEXIK Store Landing
 *
 * @package Apexik
 */
get_header();
?>
<main id="main" class="apx-main"><?php while ( have_posts() ) : the_post(); ?><header class="apx-page-hero"><div class="apx-shell"><h1><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?></div></header><div class="apx-content"><?php the_content(); ?></div><section class="apx-section"><div class="apx-shell"><?php apx_render_product_loop( array( 'limit' => 8 ) ); ?></div></section><?php endwhile; ?></main>
<?php get_footer(); ?>
