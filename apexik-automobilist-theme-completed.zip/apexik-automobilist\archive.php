<?php
/** Generic archive. */
require get_template_directory() . '/index.php';
